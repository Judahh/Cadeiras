/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util.interfaces;

/**
 *
 * @author judah
 */
public interface Queues extends Common{
    
}
