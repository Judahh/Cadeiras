package tcp;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class ClientUDP implements Runnable {

	private InetAddress adress;
	private int port = 4053;
	private DatagramSocket socket;
	private DatagramPacket packet;

	private String[] list = { "AB", "176", "3OL", "B65", "DXZ", "RT" };

	public ClientUDP() throws IOException {
		adress = InetAddress.getLocalHost();
		new Thread(this).start();
		send();

	}

	private void send() throws IOException {
		socket = new DatagramSocket();
		for (int i = 0; i < list.length; i++) {
			byte[] dados = list[i].getBytes();
			packet = new DatagramPacket(dados, dados.length, adress, port);
			socket.send(packet);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Enviado: " + list[i]);
		}
	}

	private DatagramPacket packetReceive;
	private DatagramSocket socketReceive;

	public void run() {
		try {
			byte buffer[] = new byte[1000];
			socketReceive = new DatagramSocket(1024);
			packetReceive = new DatagramPacket(buffer, buffer.length);
			while (true) {
				socketReceive.receive(packetReceive);
				String conteudo = new String(packetReceive.getData(), 0,
						packetReceive.getLength());
				System.out.println("Pacote recebido de "
						+ packetReceive.getAddress());
				System.out.println("Conte�do do pacote: " + conteudo);
				// Redefine o tamanho do pacote
				packetReceive.setLength(buffer.length);
			}
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		try {
			new ClientUDP();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
