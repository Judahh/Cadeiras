package cinco;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import javax.sound.midi.Receiver;

public class Cliente2 {

	public static int pacotesEnviados;
	public static int pacotesRecebidos;
	
	public Cliente2() throws IOException {
		
		enviar();

	}
	
	public static void main(String[] ars) throws HostNaoEncontradoException {
		try {
			new Cliente2();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public static void enviar(){
		
		byte[] buffer = new byte[1000]; 
		try {
			// Define um endere�o de destino (IP + porta)
			InetAddress servidor = InetAddress.getByName("172.19.7.70");
			int porta = 1024;//1024;
			// Cria o socket
			DatagramSocket socket = new DatagramSocket();
			// La�o para ler linhas do teclado e envi�-las ao endere�o de destino
			//BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			
			for (int i = 0; i < 10000; i++) {
			
				pacotesEnviados++; 
				
			String linha =  "pacote " + Integer.toString(i);
			//while (!linha.equals(".")) {
				// Cria um pacote com os dados da linha
			System.out.println(linha);
				byte[] dados = linha.getBytes();
				DatagramPacket pacote = new DatagramPacket(dados, dados.length, servidor, porta);
				// Envia o pacote ao endere�o de destino
				socket.send(pacote);
				// L� a pr�xima linha
				//linha = teclado.readLine();				
			}
			
			System.out.println("Pacotes enviados: " + pacotesEnviados);
			
			receber();
			
			System.out.println("Pacotes recebidos: " + pacotesRecebidos);
			
		} catch (SocketException e1){} 
		catch(IOException e2){}	

	}
	
	public static void receber(){
		
		int porta = 1024; // Define porta
		byte[] buffer = new byte[1000]; // Cria um buffer local
		try {
			
			// Cria o socket
			DatagramSocket socket = new DatagramSocket(porta);
			// Cria um pacote para receber dados da rede no buffer local
			DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);
			// La�o para receber pacotes e mostrar seus conte�dos na sa�da padr�o
			while (true) {
				try {
					socket.receive(pacote);
					String conteudo = new String(pacote.getData(), 0, pacote.getLength());
					System.out.println("Pacote recebido de " + pacote.getAddress());
					System.out.println("Conte�do do pacote: " + conteudo);
					pacotesRecebidos++;
					// Redefine o tamanho do pacote
					pacote.setLength(buffer.length);
				
					System.out.println("Pacotes recebidos: " + pacotesRecebidos);
					
				} catch (IOException e) {}
				
			}
		} catch (SocketException e){}
	}
	
  	
}
