import java.io.IOException;
import java.net.*;

public class Servidor {
	
	private static InetAddress sendAddress;
	
	//private static DatagramSocket socket;

	public static void main(String[] args) {
		
		int porta = 1024;// Define porta
		byte[] buffer = new byte[1000]; // Cria um buffer local
		try {
			// Cria o socket
			DatagramSocket socket = new DatagramSocket(porta);
			// Cria um pacote para receber dados da rede no buffer local
			DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);
			// La�o para receber pacotes e mostrar seus conte�dos na sa�da padr�o
			while (true) {
				try {
					socket.receive(pacote);
					String conteudo = new String(pacote.getData(), 0, pacote
							.getLength());
					System.out.println("Pacote recebido de "
							+ pacote.getAddress());
					System.out.println("Conte�do do pacote: " + conteudo);
					enviarPacoteDeVolta(pacote, conteudo);
					// Redefine o tamanho do pacote
					pacote.setLength(buffer.length);
				} catch (IOException e) {
				}
			}
		} catch (SocketException e) {
		}

	}

	private static void enviarPacoteDeVolta(DatagramPacket pacote, String dados)
			throws IOException {
		DatagramSocket socket = new DatagramSocket();
		setarEndereco(pacote.getAddress());
		DatagramPacket pacoteVolta = new DatagramPacket(dados.getBytes(), dados.getBytes().length, sendAddress, 1024);
		System.out.println("Vai enviar de volta: " + new String(dados));
		socket.send(pacoteVolta);
	}
	
	private static void setarEndereco(InetAddress address) {
		try {
			sendAddress = InetAddress.getByName("172.19.7.69");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//(InetAddress)address.toString().replace('/', ' ');
	}
}
