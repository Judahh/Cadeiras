import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class SerialServerSocket {

	public static void main(String[] args) {

		try{
			
			// cria o socket servidor informando a porta
			ServerSocket server = new ServerSocket(0); // 0 especifica qualquer porta livre
			
			while (true){
				//cria o socket cliente
				Socket client = server.accept();
				//
				DataInputStream input = new DataInputStream(client.getInputStream());
				DataOutputStream output = new DataOutputStream(client.getOutputStream());
				String cliente = "Seja bem vindo ''" + client.getInetAddress().getHostName()+"'' !";
				cliente = cliente + "\n";
				output.write(cliente.getBytes());
				output.flush();
				int i;
				while ((i = input.read()) != -1){
					char c = (char)i;
					System.out.print(c);
					output.write(i);
				}
			
				
			}
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		

	}

}
