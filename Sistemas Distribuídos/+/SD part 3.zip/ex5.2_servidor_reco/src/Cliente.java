import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Cliente implements Runnable {

	
	public Cliente() throws IOException {
		
		new Thread(this).start();
		enviar();

	}
	
	public static void main(String[] ars) throws HostNaoEncontradoException {
		try {
			new Cliente();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public static void enviar(){
		
		byte[] buffer = new byte[1000]; 
		try {
			// Define um endere�o de destino (IP + porta)
			InetAddress servidor = InetAddress.getByName("172.19.7.70");
			int porta = 1024;//1024;
			// Cria o socket
			DatagramSocket socket = new DatagramSocket();
			// La�o para ler linhas do teclado e envi�-las ao endere�o de destino
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			String linha = teclado.readLine();
			while (!linha.equals(".")) {
				// Cria um pacote com os dados da linha
				byte[] dados = linha.getBytes();
				DatagramPacket pacote = new DatagramPacket(dados, dados.length, servidor, porta);
				// Envia o pacote ao endere�o de destino
				socket.send(pacote);
				// L� a pr�xima linha
				linha = teclado.readLine();				
			}			
		} catch (SocketException e1){} 
		catch(IOException e2){}	

	}
	
	public  void run(){
		
		int porta = 1024; // Define porta
		byte[] buffer = new byte[1000]; // Cria um buffer local
		try {
			
			// Cria o socket
			DatagramSocket socket = new DatagramSocket(porta);
			// Cria um pacote para receber dados da rede no buffer local
			DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);
			// La�o para receber pacotes e mostrar seus conte�dos na sa�da padr�o
			while (true) {
				try {
					socket.receive(pacote);
					String conteudo = new String(pacote.getData(), 0, pacote.getLength());
					System.out.println("Pacote recebido de " + pacote.getAddress());
					System.out.println("Conte�do do pacote: " + conteudo);
					// Redefine o tamanho do pacote
					pacote.setLength(buffer.length);
				} catch (IOException e) {}
				
			}
		} catch (SocketException e){}
	}
	
  	
}
