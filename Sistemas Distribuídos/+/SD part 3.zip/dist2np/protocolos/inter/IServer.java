package protocolos.inter;

public interface IServer {

	IConnection accept();

}
