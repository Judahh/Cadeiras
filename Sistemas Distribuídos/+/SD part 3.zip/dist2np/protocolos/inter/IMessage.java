package protocolos.inter;

public interface IMessage {

	byte[] getBytes();

	int setBytes(byte[] data);

}
