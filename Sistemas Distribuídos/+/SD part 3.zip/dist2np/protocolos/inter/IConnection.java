package protocolos.inter;

public interface IConnection {

	
	int send(IMessage m);

	int receive(IMessage m);

	void close();

}