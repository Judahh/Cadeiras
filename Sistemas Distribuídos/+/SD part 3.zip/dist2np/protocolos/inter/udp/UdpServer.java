package protocolos.inter.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import protocolos.inter.IConnection;
import protocolos.inter.Server;


public class UdpServer implements Server {

	private DatagramSocket serverSocket;
	private DatagramPacket packet;

	public UdpServer(int porta) {
		try {
			serverSocket = new DatagramSocket(porta);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public IConnection accept() {
		UdpIConnection retorno = null;
		try {
			byte[] buffer = new byte[1024];
			packet = new DatagramPacket(buffer, buffer.length);
			serverSocket.receive(packet);
			retorno = new UdpIConnection(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return retorno;
	}
}
