package protocolos.inter.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import protocolos.inter.IConnection;
import protocolos.inter.IMessage;


public class ConexaoUDP implements IConnection {

	private DatagramSocket socket;

	private DatagramPacket packet;

	private InetAddress hostAddress;

	private int porta;

	public ConexaoUDP(InetAddress hostAddress, int porta) {

		try {
			socket = new DatagramSocket();
			this.hostAddress = hostAddress;
			this.porta = porta;
		} catch (SocketException e) {
			e.printStackTrace();
		}

	}

	protected ConexaoUDP(DatagramPacket packet) {
		this.packet = packet;
	}

	public void close() {
		socket.close();
	}

	public int receive(IMessage m) {
		m.setBytes(packet.getData());
		return m.getBytes().length;
	}

	public int send(IMessage m) {
		byte[] buffer = m.getBytes();
		try {
			packet = new DatagramPacket(buffer, buffer.length, hostAddress, porta);
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer.length;
	}

	public DatagramPacket getPacket() {
		return packet;
	}

	public void setPacket(DatagramPacket packet) {
		this.packet = packet;
	}
}
