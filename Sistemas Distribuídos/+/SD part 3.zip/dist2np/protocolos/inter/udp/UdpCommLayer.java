package protocolos.inter.udp;

import java.net.InetAddress;

import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IServer;


public class UdpCommLayer implements CamadaCon{

	public IConnection acceptConnection(IServer s) {
		return s.accept();
	}

	public IServer createServer(int porta) {
		return new ServidorUDP(porta);
	}

	public IConnection openConnection(InetAddress hostAddress, int porta) {
		return new ConexaoUDP(hostAddress, porta);
	}

}
