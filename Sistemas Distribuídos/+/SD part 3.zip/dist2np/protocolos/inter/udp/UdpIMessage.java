package protocolos.inter.udp;

import protocolos.inter.IMessage;

public class UdpIMessage implements IMessage{

	private byte[] data = null;

	public byte[] getBytes() {
		return data;
	}

	public int setBytes(byte[] data) {
		this.data = data;
		return data.length;
	}
	
	public int getLength(){
		return data.length;
	}


}
