package protocolos.inter.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import protocolos.inter.IConnection;
import protocolos.inter.IServer;


public class ServidorUDP implements IServer {

	private DatagramSocket serverSocket;
	private DatagramPacket packet;

	public ServidorUDP(int porta) {
		try {
			serverSocket = new DatagramSocket(porta);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public IConnection accept() {
		ConexaoUDP retorno = null;
		try {
			byte[] buffer = new byte[1024];
			packet = new DatagramPacket(buffer, buffer.length);
			serverSocket.receive(packet);
			retorno = new ConexaoUDP(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return retorno;
	}
}
