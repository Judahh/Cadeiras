package protocolos.inter.tcp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import protocolos.inter.IConnection;
import protocolos.inter.IServer;


public class ServidorTCP implements IServer {

	private ServerSocket serverSocket;

	public ServidorTCP(int porta) {
		try {
			serverSocket = new ServerSocket(porta);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public IConnection accept() {
		ConexaoTCP retorno = null;
		try {
			Socket socket = serverSocket.accept();
			// abrir conexao TCP
			retorno = new ConexaoTCP(socket);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return retorno;
	}
}
