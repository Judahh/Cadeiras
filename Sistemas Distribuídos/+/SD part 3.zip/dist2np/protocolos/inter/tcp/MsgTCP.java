package protocolos.inter.tcp;

import protocolos.inter.IMessage;

public class MsgTCP implements IMessage{

	private byte[] data = null;

	public byte[] getBytes() {
		return data;
	}

	public int setBytes(byte[] data) {
		this.data = data;
		return data.length;
	}


}
