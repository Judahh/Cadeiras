package protocolos.inter.tcp;


import java.net.InetAddress;

import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IServer;


public class TcpCommLayer implements CamadaCon{

	public IConnection acceptConnection(IServer s) {
		return s.accept();
	}

	public IServer createServer(int porta) {
		return new ServidorTCP(porta);
	}

	public IConnection openConnection(InetAddress hostAddress, int porta) {
		return new ConexaoTCP(hostAddress, porta);
	}

}
