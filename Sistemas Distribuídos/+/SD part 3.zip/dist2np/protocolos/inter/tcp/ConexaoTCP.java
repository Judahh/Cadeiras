package protocolos.inter.tcp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import protocolos.inter.IConnection;
import protocolos.inter.IMessage;

class ConexaoTCP implements IConnection {

	private Socket socket;

	public ConexaoTCP(InetAddress hostAddress, int porta) {
		try {
			socket = new Socket(hostAddress, porta);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected ConexaoTCP(Socket socket) {
		this.socket = socket;
	}

	public void close() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int receive(IMessage m) {

		int retorno = 0;

		try {
			byte[] buffer = new byte[1024];
			m.setBytes(buffer);
			InputStream in = socket.getInputStream();
			retorno = in.read(buffer);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return retorno;
	}

	public int send(IMessage m) {

		byte[] buffer = new byte[0];

		try {
			buffer = m.getBytes();
			OutputStream in = socket.getOutputStream();
			in.write(buffer);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return buffer.length;
	}
}
