package protocolos.inter;

public interface Server {

	IConnection accept();

}
