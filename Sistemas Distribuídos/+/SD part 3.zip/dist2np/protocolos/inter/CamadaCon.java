package protocolos.inter;

import java.net.*;

public interface CamadaCon {

	IConnection openConnection(InetAddress hostAdress, int porta);

	IServer createServer(int porta);

	IConnection acceptConnection(IServer s);

}
