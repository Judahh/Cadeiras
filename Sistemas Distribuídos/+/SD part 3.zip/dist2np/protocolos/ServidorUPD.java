package protocolos;

import java.net.InetAddress;
import java.util.Vector;


import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IMessage;
import protocolos.inter.IServer;
import protocolos.inter.udp.ConexaoUDP;
import protocolos.inter.udp.MsgUDP;
import protocolos.inter.udp.ServidorUDP;
import protocolos.inter.udp.UdpCommLayer;


public class ServidorUPD extends Thread {

	public void run() {
		
		
		try {
			Vector<ClienteUDP> clientesUDP = new Vector<ClienteUDP>();
			int[] qtdesPalitosJogadores = new int[4]; // quantidade de palitos que cada jogador tem na m�o
			int[] qtdesPalitosJogadoresTotal = new int[4]; // quantidade de palitos que cada jogador acha que tem ao total
			boolean acabou = false;
			// cria socket do servidor com a porta 9876
			CamadaCon cl = new UdpCommLayer();
			IServer serv = cl.createServer(9876);

			//byte[] receiveData = new byte[1024];
			//byte[] sendData = new byte[1024];
			while (true) {
				System.out.println("ServidorUPD aguardando...");
				IConnection ic = cl.acceptConnection(serv);
				System.out.println("ServidorUPD recebeu...");

				// pega os dados, o endere�o IP e a porta do cliente
				// para poder mandar a msg de volta
				IMessage im = new MsgUDP();

				int x = ic.receive(im);

				byte[] bytes = new byte[x];

				System.arraycopy(im.getBytes(), 0, bytes, 0, x);

				String sentence = new String(bytes);
				InetAddress IPAddress = ((ConexaoUDP)ic).getPacket().getAddress();
				//int port = ((ConexaoUDP)ic).getPacket().getPort();
				// receber pacote e analisar o que fazer com ele

				if (sentence.substring(0, 10).equalsIgnoreCase("querojogar")) {
					// marca endere�o IP do cliente e adiciona ele no vetor
					ClienteUDP udpcliente = new ClienteUDP();
					udpcliente.setIpadress(IPAddress);
					clientesUDP.add(udpcliente);
					if (clientesUDP.size() == 2) {
						// ja come�a a partida
						for (int i = 0; i < clientesUDP.size(); i++) {
							// envia ao cliente
							IConnection ic2 = cl.openConnection(clientesUDP.get(i).getIpadress(), 9876);
							IMessage im2 = new MsgUDP();
							im2.setBytes(new String("Iniciando...").getBytes());
							System.out.println("Enviando para:"
									+ clientesUDP.get(i).getIpadress());
							ic2.send(im2);
						}
						
											
						
						InetAddress ganhador = null;  //para saber quem � o vencedor no final
						do {
							for (int i = 0; i < clientesUDP.size(); i++) {
								IConnection ic2 = cl.openConnection(clientesUDP.get(i).getIpadress(), 9876);
								IMessage im2 = new MsgUDP();
								im2.setBytes(new String("Quantos palitos voc� tem na m�o?").getBytes());
								ic2.send(im2);
								
								// espera obter resposta...
								IConnection ic3 = cl.acceptConnection(serv);
								
								IMessage im3 = new MsgUDP();

								int y = ic3.receive(im3);

								byte[] bytes2 = new byte[y];

								System.arraycopy(im3.getBytes(), 0, bytes2, 0, y);

								String respServidor = new String(bytes2);
								
								String respServidorModified = "";
								for (int j = 0; j < respServidor.length(); j++) {
									if (new Character(respServidor.charAt(j)).isDigit(respServidor.charAt(j))
											|| new Character(respServidor.charAt(j)).isLetter(respServidor.charAt(j))) {
										respServidorModified = respServidorModified	+ respServidor.charAt(j);
									}
								}

								qtdesPalitosJogadores[i] = Integer.parseInt(respServidorModified);
							}

							for (int i = 0; i < clientesUDP.size(); i++) {
								IConnection ic2 = cl.openConnection(clientesUDP.get(i).getIpadress(), 9876);
								IMessage im2 = new MsgUDP();
								im2.setBytes(new String("Quantos palitos voc� acha que tem ao total?").getBytes());
								ic2.send(im2);
								
								// espera obter resposta...
								IConnection ic3 = cl.acceptConnection(serv);
								
								IMessage im3 = new MsgUDP();

								int y = ic3.receive(im3);

								byte[] bytes3 = new byte[y];

								System.arraycopy(im3.getBytes(), 0, bytes3, 0, y);

								String respServidor = new String(bytes3);
								String respServidorModified = "";
								for (int j = 0; j < respServidor.length(); j++) {
									if (new Character(respServidor.charAt(j)).isDigit(respServidor.charAt(j))
											|| new Character(respServidor.charAt(j)).isLetter(respServidor.charAt(j))) {
										respServidorModified = respServidorModified	+ respServidor.charAt(j);
									}
								}

								qtdesPalitosJogadoresTotal[i] = Integer.parseInt(respServidorModified);
							}

							// calcula total de palitos na rodada
							int somaTotal = 0;
							for (int i = 0; i < qtdesPalitosJogadores.length; i++)
								somaTotal = somaTotal + qtdesPalitosJogadores[i];
							boolean alguemAcertou = false;
							for (int i = 0; i < qtdesPalitosJogadoresTotal.length; i++) {
								if (somaTotal == qtdesPalitosJogadoresTotal[i]) {
									// jogador acertou
									alguemAcertou=true;
									System.out.println("O jogador " + clientesUDP.get(i).getIpadress()  + " est� com " + clientesUDP.get(i).getQtdePalitosMao() + "palitos na m�o.");
									for (int j = 0; j < clientesUDP.size(); j++) {
										IConnection ic2 = cl.openConnection(clientesUDP.get(j).getIpadress(), 9876);
										IMessage im2 = new MsgUDP();
										im2.setBytes(new String("O Jogador " + clientesUDP.get(i).getIpadress() + " acertou.").getBytes());
										ic2.send(im2);
									}
									clientesUDP.get(i).setQtdePalitosMao(clientesUDP.get(i).getQtdePalitosMao() - 1);
									if(clientesUDP.get(i).getQtdePalitosMao()==0){  // verificar se n�o acabou a partida
										acabou=true;
										ganhador = clientesUDP.get(i).getIpadress();
									}
									
								}
							}
							if(!alguemAcertou){  //ninguem acertou, avisa pra td mundo
								for (int j = 0; j < clientesUDP.size(); j++) {
									IConnection ic2 = cl.openConnection(clientesUDP.get(j).getIpadress(), 9876);
									IMessage im2 = new MsgUDP();
									im.setBytes(new String("Ninguem acertou.").getBytes());
									ic2.send(im);
								}
							}

						} while (!acabou);
						
						for (int j = 0; j < clientesUDP.size(); j++) {
							IConnection ic2 = cl.openConnection(clientesUDP.get(j).getIpadress(), 9876);
							IMessage im2 = new MsgUDP();
							im.setBytes(new String("O jogador " + ganhador + " foi o vencedor.").getBytes());
							ic2.send(im);
						}
					} else {
						IConnection ic2 = cl.openConnection(IPAddress, 9876);
						IMessage im2 = new MsgUDP();
						im2.setBytes(new String(
								"Quantidade de jogadores at� o momento:" + clientesUDP.size() + ". Espere entrar mais " + (2 - clientesUDP.size()) + " jogador.").getBytes());
						ic2.send(im2);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/*public void enviarMsg(String msg) { // retorna resposta do servidor
		try {
			byte[] sendData = msg.getBytes();
			// byte[] sendData = "marrapaiz".getBytes();
			// declara socket cliente
			DatagramSocket clientSocket = new DatagramSocket();

			// obtem endere�o IP do servidor com o DNS
			InetAddress IPAddress = InetAddress.getByName("marcos");

			// cria pacote com o dado, o endere�o do server e porta do servidor
			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, 9876);

			// envia o pacote
			clientSocket.send(sendPacket);

			// declara o pacote a ser recebido
			
			 * DatagramPacket receivePacket = new DatagramPacket(receiveData,
			 * receiveData.length); // recebe pacote do servidor
			 * clientSocket.receive(receivePacket); // separa somente o dado
			 * recebido //String modifiedSentence = new
			 * String(receivePacket.getData()); // mostra no v�deo
			 * //System.out.println("FROM SERVER:" + modifiedSentence); String
			 * respServidor = new String(receivePacket.getData()); String
			 * respServidorModified = ""; for(int i=0;i<respServidor.length();i++){
			 * if(new
			 * Character(respServidor.charAt(i)).isDigit(respServidor.charAt(i)) ||
			 * new
			 * Character(respServidor.charAt(i)).isLetter(respServidor.charAt(i)) ||
			 * respServidor.charAt(i) ==' ' || respServidor.charAt(i) =='.' ||
			 * respServidor.charAt(i) ==':' ){ respServidorModified =
			 * respServidorModified+respServidor.charAt(i); } }
			 * areaJogo.append(respServidorModified + "\n");
			 

			// fecha o cliente
			clientSocket.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	public static void main(String args[]) {
		
		new ServidorUPD().start();
		
		/*
		 * ConexaoUDP conexao = (ConexaoUDP)new
		 * ServidorUDP(9876).accept(); while(true){ MsgUDP udpim = new
		 * MsgUDP(); conexao.receive(udpim); System.out.println(new
		 * String(udpim.getBytes())); }
		 */
	}
}
