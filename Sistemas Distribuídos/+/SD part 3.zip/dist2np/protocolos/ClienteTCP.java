package protocolos;

import java.net.InetAddress;

import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IMessage;
import protocolos.inter.IServer;
import protocolos.inter.tcp.MsgTCP;
import protocolos.inter.tcp.TcpCommLayer;

import tela.Principal;

public class ClienteTCP {

	public ClienteTCP() {
		qtdePalitosMao = 3;
	}

	private int qtdePalitosMao;

	private InetAddress ipadress;

	private String nick;
	
	
	private String msgServidor;
	
	private int pontos;

	public void run(Principal im) {
		try {
			CamadaCon cl = new TcpCommLayer();
			IServer serv = cl.createServer(9876);
						
			while(true){
				System.out.println("CLienteTCP : Aguardando resposta...");
				IConnection ic2 = cl.acceptConnection(serv);
				System.out.println("CLienteTCP : Recebi...");
				
				IMessage im2 = new MsgTCP();

				int j = ic2.receive(im2);

				byte[] bytes = new byte[j];

				System.arraycopy(im2.getBytes(), 0, bytes, 0, j);

				String respServidor = new String(bytes);
				String respServidorModified = "";
				for (int i = 0; i < respServidor.length(); i++) {
					if (new Character(respServidor.charAt(i))
							.isDigit(respServidor.charAt(i))
							|| new Character(respServidor.charAt(i))
									.isLetter(respServidor.charAt(i))
							|| respServidor.charAt(i) == ' '
							|| respServidor.charAt(i) == '.'
							|| respServidor.charAt(i) == ':') {
						respServidorModified = respServidorModified
								+ respServidor.charAt(i);
					}
				}
				im.getAreaJogo().append(respServidorModified + "\n");
				if(respServidorModified.equalsIgnoreCase("Iniciando...")){
					im.getJogadores().setText("");
					im.getJogadores().append(im.getJtfNick().getText() + " : " + InetAddress.getLocalHost());
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enviarMsg(String msg, String ipServer) { // retorna resposta do servidor
		try {
			CamadaCon cl = new TcpCommLayer();
			IConnection ic = cl.openConnection(InetAddress.getByName(ipServer), 9876);
			IMessage im = new MsgTCP();
			im.setBytes(msg.getBytes());
			ic.send(im);
			
	    } catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getQtdePalitosMao() {
		return qtdePalitosMao;
	}

	public void setQtdePalitosMao(int qtdePalitosMao) {
		this.qtdePalitosMao = qtdePalitosMao;
	}

	public InetAddress getIpadress() {
		return ipadress;
	}

	public void setIpadress(InetAddress ipadress) {
		this.ipadress = ipadress;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getMsgServidor() {
		return msgServidor;
	}

	public void setMsgServidor(String msgServidor) {
		this.msgServidor = msgServidor;
	}

	public int getPontos() {
		return pontos;
	}

	public void setPontos(int pontos) {
		this.pontos = pontos;
	}

}