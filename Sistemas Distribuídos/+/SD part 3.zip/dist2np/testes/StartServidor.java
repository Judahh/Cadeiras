package testes;

import java.net.InetAddress;

import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IMessage;
import protocolos.inter.IServer;
import protocolos.inter.udp.MsgUDP;
import protocolos.inter.udp.ServidorUDP;
import protocolos.inter.udp.UdpCommLayer;


public class StartServidor extends ServidorUDP {

	public StartServidor(int porta) {
		super(porta);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		try{
			CamadaCon cl = new UdpCommLayer();

			IServer serv = cl.createServer(7000);
			while(true){
				System.out.println("StartServidor aguardando...");
				IConnection ic = cl.acceptConnection(serv);
				System.out.println("StartServidor recebeu...");

				IMessage im = new MsgUDP();

				int i = ic.receive(im);

				byte[] bytes = new byte[i];

				System.arraycopy(im.getBytes(), 0, bytes, 0, i);

				String s = new String(bytes);

				System.out.println("StartServidor: "+ s);
				// loopback 127.0.0.1
				IConnection ic2 = cl.openConnection(InetAddress.getLocalHost(), 7000);
				IMessage im2 = new MsgUDP();
				im.setBytes(s.getBytes());
				ic2.send(im);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
