package testes;

import java.net.InetAddress;

import protocolos.inter.*;
import protocolos.inter.udp.*;

public class Cliente {

	public static void main(String[] args) {
		try {
			CamadaCon cl = new UdpCommLayer();
			// CommLayer cl = new TcpCommLayer();
			IConnection ic = cl.openConnection(InetAddress.getLocalHost(), 7663);
			IMessage im = new UdpIMessage();
			String s = "oi";
			im.setBytes(s.getBytes());
			ic.send(im);
			System.out.println("Cliente enviou: " + s);
			
			Server serv = (Server) cl.createServer(7662);
			System.out.println("Recebendo resposta do servidor...");
			IConnection ic2 = cl.acceptConnection((IServer) serv);
			System.out.println("Recebido...");
			
			IMessage im2 = new UdpIMessage();

			int i = ic2.receive(im2);

			byte[] bytes = new byte[i];

			System.arraycopy(im2.getBytes(), 0, bytes, 0, i);

			s = new String(bytes);

			System.out.println("FROM SERVER: "+ s.toUpperCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
