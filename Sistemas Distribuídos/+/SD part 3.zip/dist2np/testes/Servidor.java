package testes;

import java.net.InetAddress;

import protocolos.inter.CamadaCon;
import protocolos.inter.IConnection;
import protocolos.inter.IMessage;
import protocolos.inter.IServer;
import protocolos.inter.Server;
import protocolos.inter.udp.UdpCommLayer;
import protocolos.inter.udp.UdpIMessage;


public class Servidor {

	public static void main(String[] args) {
		try{
			CamadaCon cl = new UdpCommLayer();

			Server serv = (Server) cl.createServer(7663);
			while(true){
				System.out.println("Servidor aguardando...");
				IConnection ic = cl.acceptConnection((IServer) serv);
				System.out.println("Servidor recebeu...");

				IMessage im = new UdpIMessage();

				int i = ic.receive(im);

				byte[] bytes = new byte[i];

				System.arraycopy(im.getBytes(), 0, bytes, 0, i);

				String s = new String(bytes);

				System.out.println("Servidor: "+ s);
				
				IConnection ic2 = cl.openConnection(InetAddress.getLocalHost(), 7662);
				IMessage im2 = new UdpIMessage();
				im.setBytes(s.getBytes());
				ic2.send(im);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
