package testes;

import java.net.InetAddress;

import protocolos.inter.*;
import protocolos.inter.udp.*;

public class TesteCLiente {

	public static void main(String[] args) {
		try {
			CamadaCon cl = new UdpCommLayer();
			// CommLayer cl = new TcpCommLayer();
			//127.0.0.1 InetAddress.getLocalHost()
			IConnection ic = cl.openConnection(InetAddress.getByName("127.0.0.1"), 7000);
			IMessage im = new MsgUDP();
			String s = "oi";
			im.setBytes(s.getBytes());
			ic.send(im);
			System.out.println("TesteCLiente enviou: " + s);
			
			IServer serv = cl.createServer(7000);
			System.out.println("Recebendo resposta do servidor...");
			IConnection ic2 = cl.acceptConnection(serv);
			System.out.println("Recebido...");
			
			IMessage im2 = new MsgUDP();

			int i = ic2.receive(im2);

			byte[] bytes = new byte[i];

			System.arraycopy(im2.getBytes(), 0, bytes, 0, i);

			s = new String(bytes);

			System.out.println("FROM SERVER: "+ s.toUpperCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
