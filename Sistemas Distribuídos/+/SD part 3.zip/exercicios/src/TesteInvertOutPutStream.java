import java.io.IOException;
import java.util.Scanner;

public class TesteInvertOutPutStream {

	private static InvertOutputStream invertOutputStream;

	/** 
	 * Exercicio 2.1
	 * @author Nicholas,Simiao,Samuel	
	 */
	public static void main(String[] args) throws IOException {
		
		
		invertOutputStream = new InvertOutputStream(System.out);		
		
		String texto;//= "Qualquer coisa";
		
		Scanner dados = new Scanner(System.in);   
		
		System.out.println("Digite um texto: ");
		
		texto = dados.nextLine();
				 
		System.out.print("Texto invertido: ");
		
		invertOutputStream.write(texto.getBytes());
		invertOutputStream.flush();
		
		// 2.2
		/*
		invertInputStream = new InvertInputStream(System.in);
		
		Scanner input = new Scanner(System.in);   
		
		System.out.println("Digite um texto: ");
		
		invertInputStream.read(texto.getBytes());
		invertOutputStream.flush();
	
		texto = invertInputStream.read(data);
				 
		System.out.print("Texto invertido: ");
		*/

	}

}