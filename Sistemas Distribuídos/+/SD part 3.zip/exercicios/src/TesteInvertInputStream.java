import java.io.IOException;
import java.util.Scanner;

public class TesteInvertInputStream {

    private static InvertInputStream invertInputStream;

    public static void main(String[] args) throws IOException {
    	
    	String texto;
    	
    	invertInputStream = new InvertInputStream(System.in);

        byte[] bytes = new byte[5];
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Digite o texto a ser invertido pelo InvertInputStream: [5 caracteres]");
        
        texto = input.nextLine();
        
        invertInputStream.read(texto.getBytes());
                
        System.out.println("Texto invertido: " + new String(texto.getBytes()));
    	
        invertInputStream.close();
    }
}
