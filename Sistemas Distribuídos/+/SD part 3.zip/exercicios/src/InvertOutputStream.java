import java.io.IOException;
import java.io.OutputStream;

public class InvertOutputStream extends OutputStream {

	private OutputStream outputStream;

	public InvertOutputStream(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	public void write(int b) throws IOException {
		outputStream.write(b);
	}

	public void flush() throws IOException {
		outputStream.flush();
	}

	public void write(byte[] bytes) throws IOException {
		write(bytes, 0, bytes.length - 1);
	}

	public void write(byte[] bytes, int offset, int length) throws IOException {

		// Percorrendo o Array de Bytes de forma invertida
		for (int i = length; i >= offset; i--) {
			write(bytes[i]);
		}
	}

}