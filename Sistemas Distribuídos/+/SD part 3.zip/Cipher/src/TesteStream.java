import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;

public class TesteStream {

	public static void main(String[] args) {
		try {
			testWriter();
			//System.out.println();
			testReader();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	private static void testWriter() throws IOException {
	
		 System.out.print("Digite o Texto a ser cifrado:");
		 
		  final char temp[] = new char[50];
		  final InputStreamReader inputStreamReader = new InputStreamReader(System.in);
		  inputStreamReader.read(temp);
		
		  OutputStreamWriter osw = new OutputStreamWriter(System.out);
		  CipherWriter cw = new CipherWriter(osw);
		  cw.write(temp);
		  cw.flush();
	}
	
	private static void testReader() throws IOException {
		
		 System.out.print("Digite o Texto a ser decifrado: ");
		
		char[] temp = new char[50];
		InputStreamReader isr = new InputStreamReader(System.in);
		CipherReader cw = new CipherReader(isr);
		cw.read(temp);
		
		System.out.println(temp);
	}

}
