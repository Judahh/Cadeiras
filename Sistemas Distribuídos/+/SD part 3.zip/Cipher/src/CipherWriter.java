import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;


public class CipherWriter extends Writer {
	OutputStreamWriter osw;
	
	public static final List<List> listasCirculares = new ArrayList<List>();

	{
		char[] temp;
		List<Character> listaCircular;

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'a', 'e', 'i', 'o', 'u' };
		for (char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);
		
		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l',
				'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z' };
		for (char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'A', 'E', 'I', 'O', 'U' };
		for (char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
				'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };
		for (char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);
	}

	public CipherWriter(OutputStreamWriter osw) {
		this.osw = osw;
	}

	@Override
	public void close() throws IOException {
		osw.close();
	}

	@Override
	public void flush() throws IOException {
		osw.flush();
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		int pos;
		char caractere;
		int count = 0;

		for (char c : cbuf) 
			{
				if (count == len)
					break;
				else
				{
					caractere = c;
					for (List<Character> lista : this.listasCirculares) {
						if ((pos = lista.indexOf(c)) > -1) {
							if (pos + 1 >= lista.size()) {
								pos = -1;
							}
							caractere = lista.get(pos + 1);
							break;
						}
					}
					osw.write(caractere);
					count++;
				}
			}
	}
}