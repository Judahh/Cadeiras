import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;


public class CipherReader extends Reader {
	
	InputStreamReader isr;
	
	public static final List<List> listasCirculares = new ArrayList<List>();

	{
		char[] temp;
		List<Character> listaCircular;

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'a', 'e', 'i', 'o', 'u' };
		for (char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);
		
		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l',
				'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z' };
		for (char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'A', 'E', 'I', 'O', 'U' };
		for (char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
				'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };
		for (char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);
	}
	
	
	public CipherReader(InputStreamReader isr) {
		this.isr = isr;
	}

	@Override
	public void close() throws IOException {
		isr.close();
	}
	
	@Override
	public int read(char[] cbuf) throws IOException
	{
			return read(cbuf, 0, cbuf.length);
		
	}
	
	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		   int pos, count = 0;
	        char caractere;
	        final char tempArray[] = new char[len];
	        isr.read(tempArray);

	        
	        for (final char c : tempArray) {
	            caractere = c;
	            
	            for (final List<Character> lista : CipherReader.listasCirculares) {

	                if ((pos = lista.indexOf(c)) > -1) {
	                    
	                    if (pos == 0) {
	                        pos = lista.size();
	                    }
	                    
	                    caractere = lista.get(pos - 1);
	                    break;
	                }
	            }
	           
	            cbuf[count] = caractere;
	            count++;
	        }
	        return 0;
	}
}
