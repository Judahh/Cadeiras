
import java.io.IOException;
import java.io.OutputStream;


public class InvertOutputStream extends OutputStream {

    private OutputStream outputStream;

    public InvertOutputStream(final OutputStream outputStream) {
        this.outputStream = outputStream;
    }

    @Override
    public void write(final int b) throws IOException {
        outputStream.write(b);
    }

    @Override
    public void flush() throws IOException {
        outputStream.flush();
    }

    /**
     * Escreve bytes b.length do array de bytes especificado para este
     * outputStream.
     *
     * @param bytes O Array de bytes a ser escrito (gravado)
     */
    @Override
    public void write(final byte[] bytes) throws IOException {
        write(bytes, 0, bytes.length - 1);
    }

    @Override
    public void write(final byte[] bytes, final int inicio, final int fim) throws IOException {

        //Vari�veis de controle para evitar ArrayIndexOutOfBoundsException
        int realFim = fim;
        int realInicio = inicio;

        //Verificando se o usu�rio passou um fim maior que o tamanho m�ximo permitido
        if (realFim > bytes.length - 1) {
            realFim = bytes.length - 1;
        }

        //Verificando se o usu�rio passou um in�cio menor que 0
        if (realInicio < 0) {
            realInicio = 0;
        }

        //Percorrendo o Array de Bytes de forma invertida
        for (int i = realFim; i >= realInicio; i--) {
            //Escrevendo o byte
            write(bytes[i]);
        }
    }

}
