package br.com.sistemadistribuido.original;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

 public class ServerNew {  
    public static void main(String[] args){  
       int port = 5678;  
       String outFile = "D:\\testeServer.txt";  
       String inFile = "D:\\testeCliente.txt";  
       try {  
   
          ServerSocket MyService = new ServerSocket(port);  
          System.out.println("Aguardando conex�o...");  
   
          Socket serviceSocket = MyService.accept();  
   
          File file = new File(outFile);  
   
          DataInputStream input = new DataInputStream(new FileInputStream(file));  
          DataOutputStream output = new DataOutputStream(new FileOutputStream(inFile));  
   
          DataInputStream inputMsg = new DataInputStream(serviceSocket.getInputStream());  
          DataOutputStream outputMsg = new DataOutputStream(serviceSocket.getOutputStream());  
   
          System.out.println("IP: " + inputMsg.readUTF());  
          System.out.println("Nome: " + inputMsg.readUTF());  
   
          int readByte = inputMsg.read();    
          while (readByte !=-1) {     
             output.write((byte)readByte);     
             readByte = inputMsg.read();     
          }    
   
          inputMsg.close();  
          outputMsg.close();  
          input.close();  
          output.close();  
          serviceSocket.close();  
          MyService.close();  
       } catch (Exception e) {  
          System.err.println(e.toString());  
       }  
    }  
 } 