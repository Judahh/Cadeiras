package br.com.sistemadistribuido.original;
public class CompactadorParalelo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		long endTime, initTime = System.currentTimeMillis();
		Thread[] threads = new Thread[args.length];
		String nomeArquivo;
		
		for (int i = 0; i < args.length; i++) {
			nomeArquivo = args[i];
			threads[i] = new Thread(new Compactador(nomeArquivo));
			threads[i].start();
		}
		for (Thread thread : threads) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Arquivos compactados com sucesso.");
		endTime = System.currentTimeMillis();
		System.out.println("FINALIZADO.");
		System.out.println("Tempo final decorrido: "
				+ Compactador.exibeEmHoras(endTime - initTime) + "("
				+ (endTime - initTime) + ")");
	}
}
