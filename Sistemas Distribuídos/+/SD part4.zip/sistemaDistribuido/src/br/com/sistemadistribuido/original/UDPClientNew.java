package br.com.sistemadistribuido.original;

import static br.com.sistemadistribuido.api.util.UDPUtil.getDadosValidos;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

class UDPClientNew {
	
	private static final String HOST = "192.168.0.164";
	private static final int PORTA = 1025;
	private static final String MENSAGEM = "Alo Mundo";

	public static void main(String args[]) throws Exception {

		// declara socket cliente
		DatagramSocket clientSocket = new DatagramSocket();

		// obtem endere�o IP do servidor com o DNS
		InetAddress IPAddress = InetAddress.getByName(HOST);

		byte[] sendData = new byte[1024];
		byte[] receiveData = new byte[1024];

		// l� uma linha do teclado
		sendData = MENSAGEM.getBytes();

		// cria pacote com o dado, o endere�o do server e porta do servidor
		DatagramPacket sendPacket = new DatagramPacket(sendData,
				sendData.length, IPAddress, PORTA);

		// envia o pacote
		clientSocket.send(sendPacket);

		// declara o pacote a ser recebido
		DatagramPacket receivePacket = new DatagramPacket(receiveData,
				receiveData.length);

		// recebe pacote do servidor
		clientSocket.receive(receivePacket);

		// separa somente o dado recebido
		String modifiedSentence = getDadosValidos(receivePacket);

		// mostra no v�deo
		System.out.println("FROM SERVER:" + modifiedSentence);

		// fecha o cliente
		clientSocket.close();
	}
	
}
