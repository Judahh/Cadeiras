package br.com.sistemadistribuido.cipher.core;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import br.com.sistemadistribuido.cipher.util.ListaCircular;

/**
 * Classe que "decifra" os caracteres cifrados pela classe
 * CipherWriter. Usa a mesma regra, sendo que ao contr�rio
 *
 * @author Tiago, Samira e Romulo
 * @since 31/08/2009
 */
public class CipherReader extends Reader {

    /**
     * InputStreamReader que ser� decifrado
     */
    private InputStreamReader inputStreamReader;

    private final ListaCircular listaCircular;

    /**
     * Construtor da classe
     *
     * @param inputStreamReader O InputStreamReader que ser� decifrado
     */
    public CipherReader(final InputStreamReader inputStreamReader) {
        this.inputStreamReader = inputStreamReader;
        this.listaCircular = new ListaCircular();
    }

    /**
     * Fecha o stream
     *
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        inputStreamReader.close();
    }

    /**
     * Le um array de caracteres decifrando (usando as regras
     * definidas no coment�rio da classe) completo
     *
     * @param cbuf
     * @throws IOException
     */
    @Override
    public int read(final char[] cbuf) throws IOException {
        return read(cbuf, 0, cbuf.length);
    }

    /**
     * Le um array de caracteres decifrando (usando as regras
     * definidas no coment�rio da classe) a partir do �nicio e fim
     * passados como par�metros.
     *
     * @param cbuf
     * @param inicio
     * @param fim
     * @throws IOException
     */
    @Override
    public int read(final char[] cbuf, final int inicio, final int fim) throws IOException {
        int pos, count = 0;
        char caractere;
        final char tempArray[] = new char[fim];
        inputStreamReader.read(tempArray);

        //Percorrendo o Array de caracteres
        for (final char c : tempArray) {
            caractere = c;
            //Percorrendo as listasCirculares
            for (final List<Character> lista : listaCircular.listasCirculares) {
                //Verificando se o caractere est� na listaCircular
                if ((pos = lista.indexOf(c)) > -1) {
                    //Tratamento pra evitar IndexOutOfBoundsException
                    if (pos == 0) {
                        pos = lista.size();
                    }
                    //Se tiver na lista, pega o anterior
                    caractere = lista.get(pos - 1);
                    break;
                }
            }
            //Trocando o caractere
            cbuf[count] = caractere;
            count++;
        }
        return 0;
    }
}
