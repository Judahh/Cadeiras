package br.com.sistemadistribuido.original;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

class UDPServer {

	public static void main(String args[]) throws Exception {

		// cria socket do servidor com a porta 9876
		DatagramSocket serverSocket = new DatagramSocket(9876);

		byte[] receiveData = new byte[1024];
		byte[] sendData = new byte[1024];
		while (true) {
			// declara o pacote a ser recebido
			DatagramPacket receivePacket = new DatagramPacket(receiveData,
					receiveData.length);

			// recebe o pacote do cliente
			serverSocket.receive(receivePacket);

			// pega os dados, o endere�o IP e a porta do cliente
			// para poder mandar a msg de volta
			String sentence = new String(receivePacket.getData());
			InetAddress IPAddress = receivePacket.getAddress();
			int port = receivePacket.getPort();

			// transforma em mai�sculas
			String capitalizedSentence = sentence.toUpperCase();
			sendData = capitalizedSentence.getBytes();

			// monta o pacote com ender�o IP e porta
			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, port);

			// envia ao cliente
			serverSocket.send(sendPacket);
		}
	}
}
