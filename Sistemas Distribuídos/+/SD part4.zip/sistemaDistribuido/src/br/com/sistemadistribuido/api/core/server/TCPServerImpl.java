package br.com.sistemadistribuido.api.core.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

import br.com.sistemadistribuido.api.core.client.AbstractConnector;
import br.com.sistemadistribuido.api.util.CacheArquivo;
import br.com.sistemadistribuido.api.util.Util;

public class TCPServerImpl extends AbstractServer {
	
	private ServerSocket serverSocket;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	private Socket clientSocket;

	public TCPServerImpl(int porta) {
		super(porta);
		try {
			serverSocket = new ServerSocket(porta);
		} catch (Exception e) {
			System.out.println("Erro ao obter um ServerSocket. Erro: "
					+ e.getMessage());
		}
	}

	@Override
	public AbstractConnector aceitaConexao() throws IOException {
		AbstractConnector abstractConnector = null;
		
		while(true){
			
			clientSocket = serverSocket.accept();
			
			dataInputStream = new DataInputStream(clientSocket.getInputStream());
			dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
			
			String mensagem = dataInputStream.readUTF();
			
			processa(mensagem);
			
//			abstractConnector = new TCPConnectorImpl(clientSocket.getInetAddress(), clientSocket.getLocalPort());
//			return abstractConnector;
			
		}
		
	}
	
	public void getFile(String nomeArquivo) throws IOException {
		
		String path = Util.pathServidor;
		
		System.out.println("Host: "  + clientSocket.getInetAddress() +
				" solicitou o arquivo " + nomeArquivo);
		
		path += nomeArquivo;
        
		File arquivo = new File(path);
		
		DataInputStream input = new DataInputStream(new FileInputStream(arquivo));
		
		CacheArquivo cacheArquivo = Util.getCacheArquivo(nomeArquivo); 
		
		//Avisando que vai enviar um arquivo
		dataOutputStream.writeUTF("PUTFILE " + arquivo.getName() + " " + cacheArquivo.getDataAtualizacao().getTime());
		
		//Enviando o arquivo
		byte[] cache = new byte[10240];   
        int size = 0;   
        while ((size = input.read(cache)) > -1) {
        	dataOutputStream.write(cache, 0, size);   
        }
        
        input.close();
        dataInputStream.close();  
        dataOutputStream.close();
        dataOutputStream.flush();
		
	}

	public void putFile(String nomeArquivo, String data) throws IOException {
		
		Date dataAtualizacao = new Date(Long.parseLong(data));
		
		System.out.println("Recebendo do Host: "  + clientSocket.getInetAddress() +
				" o arquivo " + nomeArquivo);
		
		Util.atualizaCache(nomeArquivo, dataAtualizacao);
		
		String inFile = Util.pathServidor + nomeArquivo;

		DataOutputStream output = new DataOutputStream(new FileOutputStream(inFile));

		// Montando o arquivo
		int readByte = dataInputStream.read();
		while (readByte != -1) {
			output.write((byte) readByte);
			readByte = dataInputStream.read();
		}
		
		output.close();
		output.flush();
		
	}

	@Override
	public void sendMsg(String mensagem) throws IOException {
		dataOutputStream.writeUTF(mensagem);
	}

}
