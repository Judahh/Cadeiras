package br.com.sistemadistribuido.socket.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientHttp {

    public static void main(String[] args) throws IOException  {

        String modo = capturaOpcaoUsuario();

        if(modo == null){
            return;
        }

        criaClientHttp(modo);

    }

    public static void criaClientHttp(String modo) throws UnknownHostException, IOException{

        Socket s = new Socket("www.tiagorolim.com", 80);
        OutputStream ous = s.getOutputStream();
        OutputStreamWriter ousw = new OutputStreamWriter(ous);

        InputStream is = s.getInputStream();

        ousw.write(modo + " http://www.tiagorolim.com/2009/06/entendendo-o-ciclo-de-vida-jsf.html HTTP/1.0\r\n\n");

        ousw.flush();

        int read;
        while ((read = is.read()) != -1) {
            System.out.print((char) read);
        }

    }

    public static String capturaOpcaoUsuario() throws IOException {

        exibeMenu();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String opcao = in.readLine();

        if(opcao.equals("1")){
            return "GET";
        }else if(opcao.equals("2")){
            return "HEAD";
        }else if(opcao.equals("3")){
            return "OPTIONS";
        }else {
            return null;
        }

    }

    public static void exibeMenu() {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Escolha a op��o desejada:\n");
        stringBuilder.append("[1] - Obter o recurso via GET\n");
        stringBuilder.append("[2] - Obter o recurso via HEAD\n");
        stringBuilder.append("[3] - Obter o recurso via TRACE\n");
        stringBuilder.append("[4] - Sair\n");
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Op��o:");

        System.out.println(stringBuilder);

    }
}
