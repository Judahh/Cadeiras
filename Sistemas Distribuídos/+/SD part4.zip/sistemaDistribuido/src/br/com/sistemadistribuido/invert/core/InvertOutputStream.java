package br.com.sistemadistribuido.invert.core;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Classe que inverte um OutputStream. Recebe um OutputStream no construtor
 * e quando solicitado estreve esse OutputStream invertido.
 *
 * @author Tiago, Samira e Romulo
 * @since 25/08/2009
 */
public class InvertOutputStream extends OutputStream {

    /**
     * OutputStream que ser� invertido
     */
    private OutputStream outputStream;

    /**
     * Construtor da classe
     *
     * @param outputStream O OutputStream que ser� invertido
     */
    public InvertOutputStream(final OutputStream outputStream) {
        this.outputStream = outputStream;
    }

    /**
     * Escreve o byte especificado para este outputStream.
     *
     * @param b O byte a ser escrito (gravado)
     */
    @Override
    public void write(final int b) throws IOException {
        outputStream.write(b);
    }

    /**
     * Libera esse fluxo de sa�da e for�a qualquer sa�da de bytes
     * no buffer a ser escrito.
     */
    @Override
    public void flush() throws IOException {
        outputStream.flush();
    }

    /**
     * Escreve bytes b.length do array de bytes especificado para este
     * outputStream.
     *
     * @param bytes O Array de bytes a ser escrito (gravado)
     */
    @Override
    public void write(final byte[] bytes) throws IOException {
        write(bytes, 0, bytes.length - 1);
    }

    /**
     * Escreve bytes do array de bytes de forma invertida. Faz o for
     * do fim do array at� o in�cio, ou seja, percorre o array de forma
     * invertida.
     *
     * @param bytes O Array de bytes a ser escrito (gravado)
     * @param inicio A posi��o de in�cio que vai come�ar a escrever
     * @param fim A posi��o de fim que vai come�ar a escrever
     * @exception IOException
     */
    @Override
    public void write(final byte[] bytes, final int inicio, final int fim) throws IOException {

        //Vari�veis de controle para evitar ArrayIndexOutOfBoundsException
        int realFim = fim;
        int realInicio = inicio;

        //Verificando se o usu�rio passou um fim maior que o tamanho m�ximo permitido
        if (realFim > bytes.length - 1) {
            realFim = bytes.length - 1;
        }

        //Verificando se o usu�rio passou um in�cio menor que 0
        if (realInicio < 0) {
            realInicio = 0;
        }

        //Percorrendo o Array de Bytes de forma invertida
        for (int i = realFim; i >= realInicio; i--) {
            //Escrevendo o byte
            write(bytes[i]);
        }
    }

}
