package br.com.sistemadistribuido.invert.teste;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import br.com.sistemadistribuido.invert.core.InvertInputStream;

/**
 * Classe de Teste para InvertInputStream
 *
 * @author Tiago, Samira e Romulo
 * @since 25/08/2009
 */
public class TestInvertInputStream {

    private InvertInputStream invertInputStream;

    /**
     * M�todo que carrega as informa��es iniciais.
     */
    @Before
    public void init(){
        invertInputStream = new InvertInputStream(System.in);
    }

    @Test
    public void testRead() throws IOException{

    }

}
