package br.com.sistemadistribuido.original;


public class MainClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Gerenciador de conex�es - Cliente");
		System.out.println(".....");
		System.out.println("Indique o tipo de conex�o desejada para o cliente:");
		System.out.println("1 -> TCP");
		System.out.println("2 -> UDP");
		System.out.println("0 -> Sair");
		

	}

}
