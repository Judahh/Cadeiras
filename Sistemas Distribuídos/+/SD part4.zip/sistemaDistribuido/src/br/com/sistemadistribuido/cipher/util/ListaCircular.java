/**
 *
 */
package br.com.sistemadistribuido.cipher.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa uma lista que cont�m 4 listas de
 * caracteres. 1� - Vogais min�sculas, 2� = Consoantes min�sculas,
 * 3� - Vogais mai�sculas, 4� = Consoantes mai�sculas
 *
 * @author Tiago, Samira e Romulo
 * @since 31/08/2009
 */
public class ListaCircular {

    public final List<List<Character>> listasCirculares = new ArrayList<List<Character>>();

    public ListaCircular(){

        char[] temp;
        List<Character> listaCircular;

        // Adicionando todas as vogais min�sculas a listaCircular
        listaCircular = new ArrayList<Character>();
        temp = new char[] { 'a', 'e', 'i', 'o', 'u' };
        for (final char vogal : temp) {
            listaCircular.add(vogal);
        }
        listasCirculares.add(listaCircular);

        // Adicionando todas as consoantes min�sculas a listaCircular
        listaCircular = new ArrayList<Character>();
        temp = new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w',
                           'x', 'y', 'z' };
        for (final char consoante : temp) {
            listaCircular.add(consoante);
        }
        listasCirculares.add(listaCircular);

        // Adicionando todas as vogais mai�sculas a listaCircular
        listaCircular = new ArrayList<Character>();
        temp = new char[] { 'A', 'E', 'I', 'O', 'U' };
        for (final char vogal : temp) {
            listaCircular.add(vogal);
        }
        listasCirculares.add(listaCircular);

        // Adicionando todas as consoantes mai�sculas a listaCircular
        listaCircular = new ArrayList<Character>();
        temp = new char[] { 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W',
                           'X', 'Y', 'Z' };
        for (final char consoante : temp) {
            listaCircular.add(consoante);
        }
        listasCirculares.add(listaCircular);
    }

}
