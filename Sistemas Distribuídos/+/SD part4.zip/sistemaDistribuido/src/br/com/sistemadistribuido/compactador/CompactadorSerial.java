package br.com.sistemadistribuido.compactador;

import java.io.File;
import java.util.Date;
import java.util.List;

import br.com.sistemadistribuido.compactador.exception.PathNotFoundException;
import br.com.sistemadistribuido.compactador.util.DateUtil;
import br.com.sistemadistribuido.compactador.util.FileUtil;

public class CompactadorSerial {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		/**
		 * --------------- 10 Arquivos Txt -------------------
		 */

		String path01 = "D:\\trabalhoSD\\arquivos\\10Arq\\Txt\\100KB";

		compactaArquivosPorDiretorio(path01);

		String path02 = "D:\\trabalhoSD\\arquivos\\10Arq\\Txt\\1MB";

		compactaArquivosPorDiretorio(path02);

		String path03 = "D:\\trabalhoSD\\arquivos\\10Arq\\Txt\\10MB";

		compactaArquivosPorDiretorio(path03);

		/**
		 * --------------- 50 Arquivos Txt-------------------
		 */

		String path04 = "D:\\trabalhoSD\\arquivos\\50Arq\\Txt\\100KB";

		compactaArquivosPorDiretorio(path04);

		String path05 = "D:\\trabalhoSD\\arquivos\\50Arq\\Txt\\1MB";

		compactaArquivosPorDiretorio(path05);

		String path06 = "D:\\trabalhoSD\\arquivos\\50Arq\\Txt\\10MB";

		compactaArquivosPorDiretorio(path06);

		/**
		 * --------------- 100 Arquivos Txt-------------------
		 */

		String path07 = "D:\\trabalhoSD\\arquivos\\100Arq\\Txt\\100KB";

		compactaArquivosPorDiretorio(path07);

		String path08 = "D:\\trabalhoSD\\arquivos\\100Arq\\Txt\\1MB";

		compactaArquivosPorDiretorio(path08);

		String path09 = "D:\\trabalhoSD\\arquivos\\100Arq\\Txt\\10MB";

		compactaArquivosPorDiretorio(path09);

		/**
		 * --------------- 10 Arquivos Bin -------------------
		 */

		String path10 = "D:\\trabalhoSD\\arquivos\\10Arq\\Bin\\100KB";

		compactaArquivosPorDiretorio(path10);

		String path11 = "D:\\trabalhoSD\\arquivos\\10Arq\\Bin\\1MB";

		compactaArquivosPorDiretorio(path11);

		String path12 = "D:\\trabalhoSD\\arquivos\\10Arq\\Bin\\10MB";

		compactaArquivosPorDiretorio(path12);

		/**
		 * --------------- 50 Arquivos Bin-------------------
		 */

		String path13 = "D:\\trabalhoSD\\arquivos\\50Arq\\Bin\\100KB";

		compactaArquivosPorDiretorio(path13);

		String path14 = "D:\\trabalhoSD\\arquivos\\50Arq\\Bin\\1MB";

		compactaArquivosPorDiretorio(path14);

		String path15 = "D:\\trabalhoSD\\arquivos\\50Arq\\Bin\\10MB";

		compactaArquivosPorDiretorio(path15);

		/**
		 * --------------- 100 Arquivos Bin-------------------
		 */

		String path16 = "D:\\trabalhoSD\\arquivos\\100Arq\\Bin\\100KB";

		compactaArquivosPorDiretorio(path16);

		String path17 = "D:\\trabalhoSD\\arquivos\\100Arq\\Bin\\1MB";

		compactaArquivosPorDiretorio(path17);

		String path18 = "D:\\trabalhoSD\\arquivos\\100Arq\\Bin\\10MB";

		compactaArquivosPorDiretorio(path18);

	}

	private static void compactaArquivosPorDiretorio(String path) {

		List<File> arquivos = null;

		try {
			arquivos = FileUtil.getFileByPath(path, "*.txt", "*.jpg");
		} catch (PathNotFoundException e) {
			e.printStackTrace();
		}

		Date dataHoraInicio = new Date();
		Date dataHoraFim = null;

		for (File file : arquivos) {
			new Compactador(file.getAbsolutePath()).run();
		}

		System.out.println("Arquivos compactados com sucesso. \n >>> No Path: " + path);

		dataHoraFim = new Date();

		System.out.println("Tempo final decorrido: "
				+ DateUtil.exibeEmHoras(dataHoraInicio, dataHoraFim));
		System.out.println("------------------------------------------------------");

	}
}
