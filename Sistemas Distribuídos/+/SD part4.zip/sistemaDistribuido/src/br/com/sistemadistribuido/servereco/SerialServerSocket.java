package br.com.sistemadistribuido.servereco;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class SerialServerSocket {

	public static void main(String[] args) {

		try{
			ServerSocket server = new ServerSocket(1024);
			
			while (true){
				Socket client = server.accept();
				DataInputStream input = new DataInputStream(client.getInputStream());
				DataOutputStream output = new DataOutputStream(client.getOutputStream());
				String wellcome = "Seja bem vindo ''" + client.getInetAddress().getHostName()+"'' !";
				wellcome = wellcome + "\n";
				output.write(wellcome.getBytes());
				output.flush();
				int i;
				while ((i = input.read()) != -1){
					char c = (char)i;
					System.out.print(c);
					output.write(i);
				}
			
				
			}
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		

	}

}
