package br.com.sistemadistribuido.original;

import java.io.IOException;

public abstract class StringServer {
	private int port;
	public StringServer(int port){
		this.port = port;
	}
	abstract StringConnector acceptConnector()throws IOException;
}
