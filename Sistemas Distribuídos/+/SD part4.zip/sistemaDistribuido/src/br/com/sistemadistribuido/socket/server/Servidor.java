package br.com.sistemadistribuido.socket.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    // Cria um ServerSocket acoplado � porta 1024
    ServerSocket server = new ServerSocket(1024);

    public Servidor() throws IOException {

        Socket cliente;

        // Cria um ServerSocket acoplado � porta 1024
        // La�o para tratamento de conex�es
        while (true) {

            cliente = server.accept();

            //Criando canal para recebimento dos dados
            DataInputStream input = new DataInputStream(cliente.getInputStream());

            //Criando mensagem de boas vindas
            DataOutputStream output = new DataOutputStream(cliente.getOutputStream());
            String wellcome = "Seja bem vindo ''" + cliente.getInetAddress().getHostName() + "'' !\n";
            output.write(wellcome.getBytes());
            output.flush();

            int read = 0;
            while ((read = input.read()) != -1) {
                System.out.print((char) read);
            }
            System.out.println();

        }

    }

    public static void main(String[] args) throws IOException {
        new Servidor();
    }

}
