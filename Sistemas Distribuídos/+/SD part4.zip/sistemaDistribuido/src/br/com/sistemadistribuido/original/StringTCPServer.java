package br.com.sistemadistribuido.original;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class StringTCPServer extends StringServer {
	
	private ServerSocket serverSocket;
	
	public StringTCPServer(int port) {
		super(port);
		try{
			serverSocket = new ServerSocket(port);
		}catch(Exception e){
			System.out.println("Erro ao obter um ServerSocket. Erro: " + e.getMessage());			
		}
	}

	@Override
	StringConnector acceptConnector() throws IOException {
		StringTCPConnector stringTCPConnector = null;
		if (serverSocket != null){
			Socket clientSocket = serverSocket.accept();
			stringTCPConnector = new StringTCPConnector(clientSocket.getInetAddress(), clientSocket.getPort());
		}
		return stringTCPConnector;
	}

}
