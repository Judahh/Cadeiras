package br.com.sistemadistribuido.api.core.server;

import java.io.IOException;

import br.com.sistemadistribuido.api.core.client.AbstractConnector;
import br.com.sistemadistribuido.api.util.CacheArquivo;
import br.com.sistemadistribuido.api.util.Util;

public abstract class AbstractServer {
	
	protected int porta;
	
	public AbstractServer(int porta){
		this.porta = porta;
	}
	
	public final void processa(String mensagem) throws IOException{
		
		if(mensagem.equals("GETLIST")){
			getList();
			return;
		}
		
		if(mensagem.startsWith("PUTFILE")){
			String[] mensagens = mensagem.split(" ");
			String nomeArquivo = mensagens[1];
			String dataAtualizacao = mensagens[2];
			putFile(nomeArquivo, dataAtualizacao);
			return;
		}
		
		if(mensagem.startsWith("GETFILE")){
			String[] mensagens = mensagem.split(" ");
			String nomeArquivo = mensagens[1];
			getFile(nomeArquivo);
			return;
		}
		
		if(mensagem.startsWith("GETCACHE")){
			String[] mensagens = mensagem.split(" ");
			String nomeArquivo = mensagens[1];
			getCache(nomeArquivo);
			return;
		}
		
	}
	
	public final void getList() throws IOException {
		
		System.out.println("Solicitado a lista de arquivos...");
		System.out.println("Lista de Arquivos com " + Util.getListaCacheArquivo().size() + " elementos!");
		
		String resposta = "";
		
		for(CacheArquivo cacheArquivo : Util.getListaCacheArquivo()){
			resposta += " "+ cacheArquivo.getNomeArquivo();
		}
		
		sendMsg(resposta);
	}
	
	public final void getCache(String nomeArquivo) throws IOException {
		
		String resposta = "";
		
		CacheArquivo cacheArquivo  = Util.getCacheArquivo(nomeArquivo);
		
		if(cacheArquivo != null){
			resposta += cacheArquivo.getDataAtualizacao().getTime();
		}
		
		sendMsg(resposta);
		
	}
	
	public abstract AbstractConnector aceitaConexao()throws IOException;
	public abstract void getFile(String nomeArquivo) throws IOException;
	public abstract void sendMsg(String mensagem) throws IOException;
	public abstract void putFile(String nomeArquivo, String data) throws IOException;

}
