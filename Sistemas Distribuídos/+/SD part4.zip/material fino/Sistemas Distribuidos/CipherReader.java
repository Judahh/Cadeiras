import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;


public class CipherReader extends Reader {
	
	InputStreamReader ipsReader;
	
	char vogais[]          = {'a', 'e', 'i', 'o', 'u'};
	char vogaisUpper[]     = {'A', 'E', 'I', 'O', 'U'};
	char consoantes[]      = {'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p',
			                  'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
	char consoantesUpper[] = {'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
			                  'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };
	
	public CipherReader(InputStreamReader inputStreamReader) {
		this.ipsReader = inputStreamReader;
	}

	@Override
	public void close() throws IOException {
		ipsReader.close();
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		int posicao;
		int contador = 0;	
		boolean achou = false;
		Character letra;
		char frase[] = new char[len];
		System.out.println("Escreva a frase cifrada:\n");
		ipsReader.read(frase);
		
		for (int i = 0; i < frase.length; i++) {
			letra = frase[i];
			
			for (int j = 0; j < vogais.length; j++) {
				 if (letra.equals(vogais[j])) {
					 if (j == 0) {
						 posicao = vogais.length;
					 }else {
						 posicao = j;
					 }
					 achou = true;
					 letra = vogais[posicao - 1];
					 break;
				 }else {
					 achou = false;
				 }				 
			}
			
			if (!achou) {
				for (int j = 0; j < vogaisUpper.length; j++) {
					 if (letra.equals(vogaisUpper[j])) {
						 if (j == 0) {
							 posicao = vogaisUpper.length;
						 }else {
							 posicao = j;
						 }
						 achou = true;
						 letra = vogaisUpper[posicao - 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			if (!achou) {
				for (int j = 0; j < consoantes.length; j++) {
					 if (letra.equals(consoantes[j])) {
						 if (j == 0) {
							 posicao = consoantes.length;
						 }else {
							 posicao = j;
						 }
						 achou = true;
						 letra = consoantes[posicao - 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			if (!achou) {
				for (int j = 0; j < consoantesUpper.length; j++) {
					 if (letra.equals(consoantesUpper[j])) {
						 if (j == 0) {
							 posicao = consoantesUpper.length;
						 }else {
							 posicao = j;
						 }
						 achou = true;
						 letra = consoantesUpper[posicao - 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			cbuf[contador] = letra;
			contador++;
		}
		
		return 0;
	}
}