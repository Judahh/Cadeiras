package br.com.SistemasDig;

import java.util.ArrayList;

import br.com.view.MainWindow;

public class CompactadorParalelo {

	/**
	 * @param args
	 */
	
	MainWindow mainWindow;
	
	public CompactadorParalelo(ArrayList<String> arquivo){
		long tempoFinal, tempoInicial = System.currentTimeMillis();
		mainWindow = MainWindow.getInstance();		
		
		
		if (mainWindow.tipoCompactador.isSelected()){

			Thread[] threads = new Thread[arquivo.size()];
			
			for (int i = 0; i < arquivo.size(); i++) {
				threads[i] = new Thread(new Compactador(arquivo.get(i)));
				threads[i].start();
			}
			for (Thread thread : threads) {
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}else{
			for (String nomeArquivo : arquivo) {
	            new Compactador(nomeArquivo).run();
	        }
		}
		
		mainWindow.logTransmissor("Arquivos compactados com sucesso.");
		tempoFinal = System.currentTimeMillis();
		mainWindow.logTransmissor("FINALIZADO.");
		mainWindow.logTransmissor("Tempo final decorrido: "+ Compactador.exibeEmSegundos(tempoFinal - tempoInicial));
	
	}
	
}

