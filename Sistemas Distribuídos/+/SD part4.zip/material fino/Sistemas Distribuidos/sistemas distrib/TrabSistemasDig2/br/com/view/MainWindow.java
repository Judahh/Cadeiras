package br.com.view;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.TextArea;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import br.com.view.MainActions;


public class MainWindow extends JFrame {
	 /**
     * Usada para formatar a data que � exibida no log.
     */
    private DateFormat timeFormat = DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM, DateFormat.MEDIUM, new Locale("pt_BR"));

    private   JPanel jContentPane = null;
    private   JTabbedPane modulos = null;
    private   JPanel moduloTransmissor = null;
    private   JScrollPane scrollPaneTransmissao = null;
    private   JTextArea logTrasmissao = null;
    private   JPanel panelAcoesTransmissao = null;
    private   JButton compactar = null;
    private   JButton inserir = null;
    private   JPanel panelMensagem = null;
    private   static MainWindow instance;
    String    arquivo;
    public JCheckBox tipoCompactador = null; 
    
//  JMenu
    private JMenu menu_configuracao;

    private JMenu menu_ajuda;

    // JMenuItem
    private JMenuItem item_Open_File;

     /**
     * This is the default constructor
     */
    public MainWindow() {
        super();
        instance = this;
        initialize();
    }

    public static MainWindow getInstance() {
        return instance;
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize() {
        this.setSize(563, 393);
        this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        this.setContentPane(getJContentPane());
        this.setTitle("Tabalho Sistemas Distribuidos");
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane() {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
            this.criaMenus();
            jContentPane.add(getModulos(), java.awt.BorderLayout.CENTER);
        }
        return jContentPane;
    }
    
   
    /**
     *Respons�vel pela cria��o dos menus 
     */
    private void criaMenus() {
        menu_configuracao = new JMenu("Arquivo");
        menu_ajuda = new JMenu("Ajuda");

        item_Open_File = new JMenuItem("Anexar");
    
        JMenuBar barraMenu = new JMenuBar();

        menu_configuracao.add(item_Open_File);
        barraMenu.add(menu_configuracao);
        barraMenu.add(menu_ajuda);
        
        //a��o_open_file
        menu_configuracao.getItem(0).setMnemonic(java.awt.event.KeyEvent.VK_E);
        menu_configuracao.getItem(0).setActionCommand(MainActions.ABRIR_ARQUIVO);
        menu_configuracao.getItem(0).addActionListener(MainActions.getInstance());
        
        //a��o_conf_file
        /*
        menu_configuracao.getItem(1).setMnemonic(java.awt.event.KeyEvent.VK_E);
        menu_configuracao.getItem(1).setActionCommand(MainActions.AJUDA);
        menu_configuracao.getItem(1).addActionListener(MainActions.getInstance());
        */
        this.setJMenuBar(barraMenu);
    }

    /**
     * This method initializes modulos	
     * 	
     * @return javax.swing.JTabbedPane	
     */
    private JTabbedPane getModulos() {
        if (modulos == null) {
            modulos = new JTabbedPane();
            modulos.addTab("Log", null, getModuloTransmissor(), null);
        }
        return modulos;
    }

    /**
     * This method initializes moduloTransmissor	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getModuloTransmissor() {
        if (moduloTransmissor == null) {
            moduloTransmissor = new JPanel();
            moduloTransmissor.setLayout(new BorderLayout());
            moduloTransmissor.add(getScrollPaneTransmissao(), java.awt.BorderLayout.CENTER);
            moduloTransmissor.add(getPanelAcoesTransmissao(), java.awt.BorderLayout.SOUTH);
        }
        return moduloTransmissor;
    }

    /**
     * This method initializes jscrollPane	
     * 	
     * @return javax.swing.JScrollPane	
     */
    private JScrollPane getScrollPaneTransmissao() {
        if (scrollPaneTransmissao == null) {
            scrollPaneTransmissao = new JScrollPane();
            scrollPaneTransmissao.setViewportView(getLogTrasmissao());
        }
        return scrollPaneTransmissao;
    }

    /**
     * This method initializes logTrasmissao	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getLogTrasmissao() {
        if (logTrasmissao == null) {
            logTrasmissao = new JTextArea();
        }
        return logTrasmissao;
    }

     /**
     * This method initializes panelAcoes	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getPanelAcoesTransmissao() {
        if (panelAcoesTransmissao == null) {
            panelAcoesTransmissao = new JPanel();
            panelAcoesTransmissao.setPreferredSize(new java.awt.Dimension(410,100));
            panelAcoesTransmissao.add(getPanelMensagem(), null);
            panelAcoesTransmissao.add(getButtonCompactar(), null);
            panelAcoesTransmissao.add(getButtonInsere(), null);
        }
        return panelAcoesTransmissao;
    }
    
    /**
     * Painel da Messagem
     */
    private JPanel getPanelMensagem() {
        if (panelMensagem == null) {
        	panelMensagem = new JPanel();
        	panelMensagem.setPreferredSize(new java.awt.Dimension(410,40));
        	//panelMensagem.setBorder(border);
        	panelMensagem.setLayout(new BorderLayout());
        	tipoCompactador = new JCheckBox("Compactador Paralelo");
            panelMensagem.add(tipoCompactador, java.awt.BorderLayout.SOUTH);
            panelMensagem.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder()));
            
        }
        return panelMensagem;
    }

    /**
     * This method initializes buttonCompactar	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getButtonCompactar() {
        if (compactar == null) {
        	compactar = new JButton();
        	compactar.setText("Compactar");
        	compactar.setMnemonic(java.awt.event.KeyEvent.VK_E);
        	compactar.setActionCommand(MainActions.COMPACTAR);
        	compactar.addActionListener(MainActions.getInstance());
        }
        return compactar;
    }
    
    /**
     * This method initializes buttonCompactar	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getButtonInsere() {
        if (inserir == null) {
        	inserir = new JButton();
        	inserir.setText("Inserir");
        	inserir.setMnemonic(java.awt.event.KeyEvent.VK_E);
        	inserir.setActionCommand(MainActions.INSERIR);
        	inserir.addActionListener(MainActions.getInstance());
        }
        return inserir;
    }

     /**
     * Escreve uma linha no log do m�dulo de transmiss�o.
     * @param msg Mensagem a ser escrita.
     */
    public void logTransmissor(String msg) {
        log(getLogTrasmissao(), msg);
    }
    
    public void clearLog(){
    	logTrasmissao.setText("");
    }

    /**
     * Escreve uma linha num objeto JTextArea.
     * @param msg Mensagem a ser escrita.
     * @param textArea Objeto onde ocorrer� o log.
     */
    private void log(JTextArea textArea, String msg) {
        textArea.append("\n" + timeFormat.format(new Date()) + ": " + msg);
        textArea.select(textArea.getText().lastIndexOf("\n") + 1, textArea.getText().length()-1);
    }
}

