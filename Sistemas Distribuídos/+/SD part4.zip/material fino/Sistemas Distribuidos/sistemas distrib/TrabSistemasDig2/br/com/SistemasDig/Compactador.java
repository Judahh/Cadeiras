package br.com.SistemasDig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import br.com.view.MainWindow;


public class Compactador implements Runnable {
    
    private String nomeArquivo;
    MainWindow mainWindow;

    public Compactador(String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
    }

    public void run() {
        File arquivo, novoArquivo;
        FileInputStream fis;
        ZipOutputStream zos;
        byte[] dadosArquivo = new byte[2048];
        mainWindow = MainWindow.getInstance();        

        arquivo = new File(nomeArquivo);
        if (arquivo.exists()) {
            try {
                fis = new FileInputStream(arquivo);
                novoArquivo = new File(nomeArquivo + ".zip");
                if (novoArquivo.createNewFile()) {
                    novoArquivo.delete();
                    novoArquivo.createNewFile();
                }
                mainWindow.logTransmissor(novoArquivo.getName() + "...." );
                zos = new ZipOutputStream(new FileOutputStream(novoArquivo));
                zos.putNextEntry(new ZipEntry(arquivo.getName()));
                while(fis.read(dadosArquivo) > 0) {
                    zos.write(dadosArquivo);
                    zos.flush();
                }
                fis.close();
                zos.close();
                mainWindow.logTransmissor("OK!");
            } catch (FileNotFoundException e) {
            	mainWindow.logTransmissor("ERRO!");
            	mainWindow.logTransmissor("Erro ao compactar ou ler arquivo " + nomeArquivo + ".");
                e.printStackTrace();
            } catch (IOException e) {
            	mainWindow.logTransmissor("ERRO2!");
            	mainWindow.logTransmissor("Erro ao escrever ou ler dados do arquivo " + nomeArquivo + ".");
                e.printStackTrace();
            }
        }
        else {
        	mainWindow.logTransmissor("Arquivo " + nomeArquivo + " n�o existe.");
        }
    }
    
    public static String exibeEmSegundos(long tempo) {
        String segundos, milisegundos, temp = "" + tempo;
        //segundos = "" + (tempo / 1000);
        /*milisegundos = ((tempo < 1000) ? temp : temp.substring(temp
                .length() - 3, temp.length()));*/ 
        return tempo + "ms";
    }
}

