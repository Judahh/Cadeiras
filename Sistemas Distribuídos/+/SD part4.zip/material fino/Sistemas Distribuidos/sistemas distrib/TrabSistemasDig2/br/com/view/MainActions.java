package br.com.view;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;

import br.com.SistemasDig.CompactadorParalelo;

public class MainActions extends AbstractAction {

    public static final String COMPACTAR = "COMPACTAR";

    public static final String INSERIR = "INSERIR";
	
	public static final String ABRIR_ARQUIVO = "ABRIR_ARQUIVO";
	
	private static MainActions instance;

    private JFileChooser fileChooser = new JFileChooser();
    
    private CompactadorParalelo compactadorParalelo;
    
    ArrayList<String> arquivos = new ArrayList<String>(0);
    int      contador = 0;
    
    private MainActions() {
        fileChooser.addActionListener(this);
    }

    private MainWindow mainWindow;

    /**
     * Executa as opera��es ao se clicar nos componentes da janela principal
     * (MainWindow).
     */
    public void actionPerformed(ActionEvent ev) {
        mainWindow = MainWindow.getInstance();
        try {
            if (ev.getActionCommand().equals(ABRIR_ARQUIVO)) {
            	try {
                    int opcao = fileChooser.showOpenDialog(mainWindow);
                    if (opcao == JFileChooser.APPROVE_OPTION) {
                        File file = fileChooser.getSelectedFile();
                        FileInputStream fileInputStream = new FileInputStream(file);
                        mainWindow.arquivo = file.getAbsolutePath(); //Aten��o
                    }
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }
            }else if (ev.getActionCommand().equals(COMPACTAR)){
            	//C�DIGO AQUI
            	mainWindow.clearLog();
            	mainWindow.logTransmissor("Processo de compacta��o:");
            	compactadorParalelo = new CompactadorParalelo(arquivos);
            }else if (ev.getActionCommand().equals(INSERIR)){
            	mainWindow.logTransmissor("Arquivo " + mainWindow.arquivo + " inserido no vetor" );
            	arquivos.add(mainWindow.arquivo);
            	contador++;
            }
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static MainActions getInstance() {
        if (instance == null) {
            instance = new MainActions();
        }
        return instance;
    }
}
