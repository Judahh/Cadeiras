package br.com.view;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class MainActions extends AbstractAction {

    public static final String INICIAR_SERVIDOR = "INICIAR_SERVIDOR";

    public static final String PARAR_SERVIDOR = "PARAR_SERVIDOR";

    public static final String AJUDA = "AJUDA";

    public static final String CONECTAR = "CONECTAR";

	public static final String ENVIAR_ARQUIVO = "ENVIAR_ARQUIVO";
	
	public static final String ABRIR_ARQUIVO = "ABRIR_ARQUIVO";
	
	private static MainActions instance;

    private JFileChooser fileChooser = new JFileChooser();
    
    private MainActions() {
        fileChooser.addActionListener(this);
    }

    private MainWindow mainWindow;

    /**
     * Executa as opera��es ao se clicar nos componentes da janela principal
     * (MainWindow).
     */
    public void actionPerformed(ActionEvent ev) {
        mainWindow = MainWindow.getInstance();
        try {
            if (ev.getActionCommand().equals(INICIAR_SERVIDOR)) {
            	//aqui
            }
        } catch (NumberFormatException ex) {
            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static MainActions getInstance() {
        if (instance == null) {
            instance = new MainActions();
        }
        return instance;
    }
}
