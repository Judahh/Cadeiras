package br.com.view;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import br.com.view.MainActions;


public class MainWindow extends JFrame {
	 /**
     * Usada para formatar a data que � exibida no log.
     */
    private DateFormat timeFormat = DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM, DateFormat.MEDIUM, new Locale("pt_BR"));

    private JPanel jContentPane = null;
    private JTabbedPane modulos = null;
    private JPanel moduloTransmissor = null;
    private JPanel moduloReceptor = null;
    private JScrollPane scrollPaneTransmissao = null;
    private JTextArea logTrasmissao = null;
    private JTextField textFieldSegmento = null;
    private JTextField textFieldPorta = null;
    private JTextField textFieldIpDestino = null;
    private JPanel panelAcoesTransmissao = null;
    private JButton buttonEnviar = null;
    private JScrollPane scrollPaneRecepcao = null;
    private JTextArea logRecepcao = null;
    public JTextArea msgEnviar = null;
    private JPanel panelConfRecepcao = null;
    private JLabel labelPortaEscuta = null;
    private JTextField textFieldPortaEscuta = null;
    private JPanel panelAcoesRecepcao = null;
    private JPanel panelMensagem = null;
    private JButton buttonIniciarServidor = null;
    private JButton buttonPararServidor = null;
    private static MainWindow instance;
    
//  JMenu
    private JMenu menu_configuracao;

    private JMenu menu_ajuda;

    // JMenuItem
    private JMenuItem item_Open_File;

     /**
     * This is the default constructor
     */
    public MainWindow() {
        super();
        instance = this;
        initialize();
    }

    public static MainWindow getInstance() {
        return instance;
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize() {
        this.setSize(563, 393);
        this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        this.setContentPane(getJContentPane());
        this.setTitle("Tabalho 2 de Redes");
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane() {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
            this.criaMenus();
            jContentPane.add(getModulos(), java.awt.BorderLayout.CENTER);
        }
        return jContentPane;
    }
    
   
    /**
     *Respons�vel pela cria��o dos menus 
     */
    private void criaMenus() {
        menu_configuracao = new JMenu("Arquivo");
        menu_ajuda = new JMenu("Ajuda");

        item_Open_File = new JMenuItem("Anexar");
    
        JMenuBar barraMenu = new JMenuBar();

        menu_configuracao.add(item_Open_File);
        barraMenu.add(menu_configuracao);
        barraMenu.add(menu_ajuda);
        
        //a��o_open_file
        menu_configuracao.getItem(0).setMnemonic(java.awt.event.KeyEvent.VK_E);
        menu_configuracao.getItem(0).setActionCommand(MainActions.ABRIR_ARQUIVO);
        menu_configuracao.getItem(0).addActionListener(MainActions.getInstance());
        
        //a��o_conf_file
        menu_configuracao.getItem(1).setMnemonic(java.awt.event.KeyEvent.VK_E);
        menu_configuracao.getItem(1).setActionCommand(MainActions.AJUDA);
        menu_configuracao.getItem(1).addActionListener(MainActions.getInstance());
        
        this.setJMenuBar(barraMenu);
    }

    /**
     * This method initializes modulos	
     * 	
     * @return javax.swing.JTabbedPane	
     */
    private JTabbedPane getModulos() {
        if (modulos == null) {
            modulos = new JTabbedPane();
            modulos.addTab("Processo", null, getModuloTransmissor(), null);
        }
        return modulos;
    }

    /**
     * This method initializes moduloTransmissor	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getModuloTransmissor() {
        if (moduloTransmissor == null) {
            moduloTransmissor = new JPanel();
            moduloTransmissor.setLayout(new BorderLayout());
            moduloTransmissor.add(getScrollPaneTransmissao(), java.awt.BorderLayout.CENTER);
            moduloTransmissor.add(getPanelAcoesTransmissao(), java.awt.BorderLayout.SOUTH);
        }
        return moduloTransmissor;
    }

    /**
     * This method initializes moduloReceptor	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getModuloReceptor() {
        if (moduloReceptor == null) {
            moduloReceptor = new JPanel();
            moduloReceptor.setLayout(new BorderLayout());
            moduloReceptor.add(getScrollPaneRecepcao(), java.awt.BorderLayout.CENTER);
            moduloReceptor.add(getPanelConfRecepcao(), java.awt.BorderLayout.SOUTH);
        }
        return moduloReceptor;
    }

    /**
     * This method initializes jscrollPane	
     * 	
     * @return javax.swing.JScrollPane	
     */
    private JScrollPane getScrollPaneTransmissao() {
        if (scrollPaneTransmissao == null) {
            scrollPaneTransmissao = new JScrollPane();
            scrollPaneTransmissao.setViewportView(getLogTrasmissao());
        }
        return scrollPaneTransmissao;
    }

    /**
     * This method initializes logTrasmissao	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getLogTrasmissao() {
        if (logTrasmissao == null) {
            logTrasmissao = new JTextArea();
        }
        return logTrasmissao;
    }

     /**
     * This method initializes panelAcoes	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getPanelAcoesTransmissao() {
        if (panelAcoesTransmissao == null) {
            panelAcoesTransmissao = new JPanel();
            panelAcoesTransmissao.setPreferredSize(new java.awt.Dimension(410,100));
            panelAcoesTransmissao.add(getPanelMensagem(), null);
            panelAcoesTransmissao.add(getButtonEnviar(), null);
        }
        return panelAcoesTransmissao;
    }
    
    /**
     * Painel da Messagem
     */
    private JPanel getPanelMensagem() {
        if (panelMensagem == null) {
        	panelMensagem = new JPanel();
        	panelMensagem.setPreferredSize(new java.awt.Dimension(410,100));
        	//panelMensagem.setBorder(border);
        	panelMensagem.setLayout(new BorderLayout());
            panelMensagem.add(getMsgEnvia(), java.awt.BorderLayout.CENTER);
            panelMensagem.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"Mensagem"));
        }
        return panelMensagem;
    }

    /**
     * This method initializes buttonEnviar	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getButtonEnviar() {
        if (buttonEnviar == null) {
            buttonEnviar = new JButton();
            buttonEnviar.setText("Enviar");
            buttonEnviar.setMnemonic(java.awt.event.KeyEvent.VK_E);
            buttonEnviar.setActionCommand(MainActions.ENVIAR_ARQUIVO);
            buttonEnviar.addActionListener(MainActions.getInstance());
        }
        return buttonEnviar;
    }

    /**
     * This method initializes jScrollPane	
     * 	
     * @return javax.swing.JScrollPane	
     */
    private JScrollPane getScrollPaneRecepcao() {
        if (scrollPaneRecepcao == null) {
            scrollPaneRecepcao = new JScrollPane();
            scrollPaneRecepcao.setViewportView(getLogRecepcao());
        }
        return scrollPaneRecepcao;
    }

    /**
     * This method initializes jTextArea	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getLogRecepcao() {
        if (logRecepcao == null) {
            logRecepcao = new JTextArea();
        }
        return logRecepcao;
    }
    
    /**
     * This method initializes jTextArea	
     * 	
     * @return javax.swing.JTextArea	
     */
    public JTextArea getMsgEnvia() {
        if (msgEnviar == null) {
        	msgEnviar = new JTextArea("Mensagem",410,100);
        	msgEnviar.setBorder(BorderFactory.createEtchedBorder());
        }
        return msgEnviar;
    }

    /**
     * This method initializes panelConfRecepcao	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getPanelConfRecepcao() {
        if (panelConfRecepcao == null) {
            GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
            gridBagConstraints8.gridx = 0;
            gridBagConstraints8.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints8.gridy = 2;
            GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
            gridBagConstraints7.fill = java.awt.GridBagConstraints.NONE;
            gridBagConstraints7.gridy = 1;
            gridBagConstraints7.weightx = 1.0;
            gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints7.gridx = 0;
            GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
            gridBagConstraints4.gridx = 0;
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints4.gridy = 0;
            labelPortaEscuta = new JLabel();
            labelPortaEscuta.setText("Porta:");
            panelConfRecepcao = new JPanel();
            panelConfRecepcao.setLayout(new GridBagLayout());
            panelConfRecepcao.setPreferredSize(new java.awt.Dimension(300,80));
            panelConfRecepcao.add(labelPortaEscuta, gridBagConstraints4);
            panelConfRecepcao.add(getTextFieldPortaEscuta(), gridBagConstraints7);
            panelConfRecepcao.add(getPanelAcoesRecepcao(), gridBagConstraints8);
        }
        return panelConfRecepcao;
    }

    /**
     * This method initializes textFieldPortaEscuta	
     * 	
     * @return javax.swing.JTextField	
     */
    public JTextField getTextFieldPortaEscuta() {
        if (textFieldPortaEscuta == null) {
            textFieldPortaEscuta = new JTextField();
            textFieldPortaEscuta.setPreferredSize(new java.awt.Dimension(60,20));
            textFieldPortaEscuta.setText("105");
        }
        return textFieldPortaEscuta;
    }

    /**
     * This method initializes jPanel	
     * 	
     * @return javax.swing.JPanel	
     */
    private JPanel getPanelAcoesRecepcao() {
        if (panelAcoesRecepcao == null) {
            panelAcoesRecepcao = new JPanel();
            panelAcoesRecepcao.setPreferredSize(new java.awt.Dimension(140,40));
            panelAcoesRecepcao.add(getButtonIniciarServidor(), null);
            panelAcoesRecepcao.add(getButtonPararServidor(), null);
        }
        return panelAcoesRecepcao;
    }

    /**
     * This method initializes buttonIniciarServidor	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getButtonIniciarServidor() {
        if (buttonIniciarServidor == null) {
            buttonIniciarServidor = new JButton();
            buttonIniciarServidor.setText("Iniciar Servidor");
            buttonIniciarServidor.setMnemonic(java.awt.event.KeyEvent.VK_I);
            buttonIniciarServidor.setActionCommand(MainActions.INICIAR_SERVIDOR);
            buttonIniciarServidor.addActionListener(MainActions.getInstance());
        }
        return buttonIniciarServidor;
    }

    /**
     * This method initializes jButton	
     * 	
     * @return javax.swing.JButton	
     */
    public JButton getButtonPararServidor() {
        if (buttonPararServidor == null) {
            buttonPararServidor = new JButton();
            buttonPararServidor.setText("Parar Servidor");
            buttonPararServidor.setEnabled(false);
            buttonPararServidor.setMnemonic(java.awt.event.KeyEvent.VK_R);
            buttonPararServidor.setActionCommand(MainActions.PARAR_SERVIDOR);
            buttonPararServidor.addActionListener(MainActions.getInstance());
        }
        return buttonPararServidor;
    }
    
    /**
     * Escreve uma linha no log do m�dulo de transmiss�o.
     * @param msg Mensagem a ser escrita.
     */
    public void logTransmissor(String msg) {
        log(getLogTrasmissao(), msg);
    }

    /**
     * Escreve uma linha no log do m�dulo de recep��o.
     * @param msg Mensagem a ser escrita.
     */
    public void logReceptor(String msg) {
        log(getLogRecepcao(), msg);
    }

    /**
     * Escreve uma linha num objeto JTextArea.
     * @param msg Mensagem a ser escrita.
     * @param textArea Objeto onde ocorrer� o log.
     */
    private void log(JTextArea textArea, String msg) {
        textArea.append("\n" + timeFormat.format(new Date()) + ": " + msg);
        textArea.select(textArea.getText().lastIndexOf("\n") + 1, textArea.getText().length()-1);
    }
}

