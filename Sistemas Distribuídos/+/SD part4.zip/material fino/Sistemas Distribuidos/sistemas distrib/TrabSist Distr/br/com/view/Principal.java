package br.com.view;

import br.com.view.MainWindow;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MainWindow().setVisible(true);
	}

}