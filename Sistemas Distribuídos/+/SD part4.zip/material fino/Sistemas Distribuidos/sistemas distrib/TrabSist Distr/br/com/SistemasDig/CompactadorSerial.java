package br.com.SistemasDig;


public class CompactadorSerial {

    /**
     * @param args
     */
    public static void main(String[] args) {
        long endTime, initTime = System.currentTimeMillis();
        String arquivo = "C:\\WildHogs.asf";
      
        new Compactador(arquivo).run();
        
        System.out.println("Arquivos compactados com sucesso.");
        endTime = System.currentTimeMillis();
        System.out.println("FINALIZADO.");
        System.out.println("Tempo final decorrido: "
                + Compactador.exibeEmHoras(endTime - initTime) + "("
                + (endTime - initTime) + ")");
    }
}


