import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class CipherWriter extends Writer {
	
	OutputStreamWriter opsWriter;
	
	char vogais[]          = {'a', 'e', 'i', 'o', 'u'};
	char vogaisUpper[]     = {'A', 'E', 'I', 'O', 'U'};
	char consoantes[]      = {'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p',
			                  'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
	char consoantesUpper[] = {'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
			                  'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };
	
	public CipherWriter(OutputStreamWriter outputStreamWriter) {
		this.opsWriter = outputStreamWriter;
	}
	
	@Override
	public void close() throws IOException {
		opsWriter.close();
	}

	@Override
	public void flush() throws IOException {
		opsWriter.flush();
	}

	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		
		int posicao;
		boolean achou = false;
		Character letra;
		
		for (int i = 0; i < cbuf.length; i++) {
			
			letra = cbuf[i];
			
			for (int j = 0; j < vogais.length; j++) {
				 if (letra.equals(vogais[j])) {
					 if (j >= vogais.length-1) {
						 posicao = -1;
					 }else {
						 posicao = j;
					 }					 
					 achou = true;
					 letra = vogais[posicao + 1];
					 break;
				 }else {
					 achou = false;
				 }				 
			}
			
			if (!achou) {
				for (int j = 0; j < vogaisUpper.length; j++) {
					 if (letra.equals(vogaisUpper[j])) {
						 if (j >= vogaisUpper.length-1) {
							 posicao = -1;
						 }else {
							 posicao = j;
						 }					 
						 achou = true;
						 letra = vogaisUpper[posicao + 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			if (!achou) {
				for (int j = 0; j < consoantes.length; j++) {
					 if (letra.equals(consoantes[j])) {
						 if (j >= consoantes.length-1) {
							 posicao = -1;
						 }else {
							 posicao = j;
						 }					 
						 achou = true;
						 letra = consoantes[posicao + 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			if (!achou) {
				for (int j = 0; j < consoantesUpper.length; j++) {
					 if (letra.equals(consoantesUpper[j])) {
						 if (j >= consoantesUpper.length-1) {
							 posicao = -1;
						 }else {
							 posicao = j;
						 }					 
						 achou = true;
						 letra = consoantesUpper[posicao + 1];
						 break;
					 }else {
						 achou = false;
					 }				 
				}
			}
			
			opsWriter.write(letra);			
		}
	}
}