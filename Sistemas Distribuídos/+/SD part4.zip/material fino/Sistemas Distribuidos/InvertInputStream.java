import java.io.IOException;
import java.io.InputStream;

public class InvertInputStream extends InputStream {
	
	private InputStream is;
	
	public InvertInputStream(InputStream is) {
		this.is = is;
	}

	public int read() throws IOException {
		return is.read();
	}
	
	public int read(byte[] bytes, int ini, int offset) throws IOException {
		int bytesCount = 0;
		int realSize = offset;
		int realIni = ini;
		if (realSize + ini > bytes.length - 1) {
			realSize = bytes.length - 1 - ini;
		}
		if (realIni < 0) {
			realIni = 0;
		}
		for (int i = realSize; i >= realIni; i--) {
			bytes[i] = (byte) read();
			bytesCount++;
		}
		return bytesCount;
	}
}