import java.io.IOException;
import java.io.OutputStream;

public class InvertOutputStream extends OutputStream {

	private OutputStream out;

	public InvertOutputStream(OutputStream out) {
		this.out = out;
	}

	public void write(int b) throws IOException {
		out.write(b);
	}

	public void write(byte[] bytes) throws IOException {
		write(bytes, 0, bytes.length-1);
	}
	
	public void write(byte[] bytes, int ini, int fim) throws IOException {
		int realFim = fim;
		int realIni = ini;
		if (realFim > bytes.length - 1) {
			realFim = bytes.length - 1;
		}
		if (realIni < 0) {
			realIni = 0;
		}
		for (int i = realFim; i >= realIni; i--) {
			write(bytes[i]);
		}
	}
	
	public void flush() throws IOException {
		out.flush();
	}
}