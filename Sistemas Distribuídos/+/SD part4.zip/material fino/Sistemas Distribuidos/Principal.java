import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;


public class Principal {
	
	public static void main(String args[]) {
		
		/*
		//-------------------- Exercicio 2.1 (InvertOutput)--------------------
		String teste = "teste123";		
		OutputStream out = new InvertOutputStream(System.out);				
		
		try {
			out.write(teste.getBytes());
			//out.flush();
			System.out.println();
		}
		catch (IOException e) {
			System.err.println();
		}
		//-------------------- Exercicio 2.1 (InvertOutput)--------------------
		*/		
		
		/*
		//-------------------- Exercicio 2.4 (Cipher Writer)--------------------
		String testeCipher = "Diego Amorimz 12��12.;\n";
		
		OutputStreamWriter opsWriter = new OutputStreamWriter(System.out);
		CipherWriter cipherWriter = new CipherWriter(opsWriter);		
		try {
			cipherWriter.write(testeCipher);
			cipherWriter.flush();			
		}
		catch (IOException e) {
			System.err.println();
		}
		//-------------------- Exercicio 2.4 (Cipher Writer)--------------------
		*/
		
		//-------------------- Exercicio 2.5 (Cipher Reader)--------------------
		char frase[] = new char[20];
		
		InputStreamReader ipsReader = new InputStreamReader(System.in);
		CipherReader cipherReader = new CipherReader(ipsReader);		
		try {
			cipherReader.read(frase);			
			System.out.println(frase);
		}
		catch (IOException e) {
			System.err.println();
		}
		//-------------------- Exercicio 2.5 (Cipher Reader)--------------------
	}
}
