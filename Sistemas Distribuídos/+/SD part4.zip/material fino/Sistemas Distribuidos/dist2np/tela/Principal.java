package tela;

import java.awt.BorderLayout;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.*;
import javax.swing.border.TitledBorder;

import protocolos.ClienteUDP;


public class Principal extends JFrame {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	private JTextArea jogadores, areaJogo;

	private JPanel jpAreaEscrita, jpPrincipal, jpJog, jpMsgServer;

	private JScrollPane jspArea, jspJog;

	private BorderLayout border;

	private JButton enviar, jogar;

	private JLabel nickJogador;
	
	public JLabel ipServ;

	private JTextField jtfNick, jtfAreaEscrever, ipServidor;
	
	private static ClienteUDP udpclient;

	public Principal() {
		setSize(800, 400);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Trabalho de Sistemas Distribu�dos");
		this.setResizable(true);
		initComponents();
	}

	public void initComponents() {
		udpclient = new ClienteUDP();
		nickJogador = new JLabel("Nick:");
		ipServ      = new JLabel("Ip Servidor:");
		jtfNick = new JTextField(10);
		ipServidor = new JTextField(15);
		enviar = new JButton("ENVIAR");
		jogar = new JButton("ENTRAR");
	    jogadores = new JTextArea("                                             ");
		jogadores.setEnabled(false);
		areaJogo = new JTextArea();
		areaJogo.setEnabled(false);
		jtfAreaEscrever = new JTextField(20);
		jpPrincipal = new JPanel();
		border = new BorderLayout();
		jpPrincipal.setLayout(border);
		jpJog = new JPanel(new BorderLayout());
		jpJog.setBorder(new TitledBorder("Jogador"));
		jpMsgServer = new JPanel(new BorderLayout());
		jpMsgServer.setBorder(new TitledBorder("Mensagens"));
		jpAreaEscrita = new JPanel();
		jspArea = new JScrollPane(areaJogo);
		jspJog = new JScrollPane(jogadores);
		jpJog.add(jspJog);
		jpAreaEscrita.add(jtfAreaEscrever);
		jpAreaEscrita.add(enviar);
		jpAreaEscrita.add(jogar);
		jpAreaEscrita.add(nickJogador);
		jpAreaEscrita.add(jtfNick);
		jpAreaEscrita.add(ipServ);
		jpAreaEscrita.add(ipServidor);
		jpMsgServer.add(jspArea);
		jpPrincipal.add(jpMsgServer, BorderLayout.CENTER);
		jpPrincipal.add(jpJog, BorderLayout.EAST);
		jpPrincipal.add(jpAreaEscrita, BorderLayout.NORTH);
		getContentPane().add(jpPrincipal, BorderLayout.CENTER);
		enviar.setEnabled(false);
		jtfAreaEscrever.setEnabled(false);
		enviar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btEnviarActionPerformed(evt);
			}
		});
		
		jogar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btJogarActionPerformed(evt);
			}
		});
	}

	private void btEnviarActionPerformed(java.awt.event.ActionEvent evt) {
		udpclient.enviarMsg(jtfAreaEscrever.getText(), ipServidor.getText());
		jtfAreaEscrever.setText("");
	}
	
	private void btJogarActionPerformed(java.awt.event.ActionEvent evt) {
		if (jtfNick.getText().equals(""))
			JOptionPane.showMessageDialog(null, "Entre com seu nick!");
		else {
			udpclient.enviarMsg("querojogar", ipServidor.getText());
			enviar.setEnabled(true);
			jtfAreaEscrever.setEnabled(true);
			enviar.setEnabled(true);
			jogar.setEnabled(false);
			jtfNick.setEnabled(false);
		}		
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Principal im = new Principal();
		im.setVisible(true);
		udpclient.run(im);
		
	}

	public JTextArea getAreaJogo() {
		return areaJogo;
	}

	public void setAreaJogo(JTextArea areaJogo) {
		this.areaJogo = areaJogo;
	}

	public JTextArea getJogadores() {
		return jogadores;
	}

	public void setJogadores(JTextArea jogadores) {
		this.jogadores = jogadores;
	}

	public JTextField getJtfNick() {
		return jtfNick;
	}

	public void setJtfNick(JTextField jtfNick) {
		this.jtfNick = jtfNick;
	}

	public JTextField getIpServidor() {
		return ipServidor;
	}

	public void setIpServidor(JTextField ipServidor) {
		this.ipServidor = ipServidor;
	}

}
