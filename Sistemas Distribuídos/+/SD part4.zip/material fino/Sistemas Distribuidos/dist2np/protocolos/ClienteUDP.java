package protocolos;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JOptionPane;

import protocolos.comm.CommLayer;
import protocolos.comm.IConnection;
import protocolos.comm.IMessage;
import protocolos.comm.Server;
import protocolos.comm.udp.UdpCommLayer;
import protocolos.comm.udp.UdpIMessage;


import tela.Principal;

/**
 * 
 * @author <a href="mailto:ncastrocosta@gmail.com">Nathanael Costa</a>
 * @author <a href="mailto:markimquixada@yahoo.com.br">Marcos Heleno</a>
 * 
 * @see ServidorUPD
 */

public class ClienteUDP {

	public ClienteUDP() {
		qtdePalitosMao = 3;
	}

	private int qtdePalitosMao;

	private InetAddress ipadress;

	private String nick;
	
	
	private String msgServidor;
	
	private int pontos;

	public void run(Principal im) {
		try {
			CommLayer cl = new UdpCommLayer();
			Server serv = cl.createServer(4567);
						
			while(true){
				System.out.println("Cliente : Aguardando resposta...");
				IConnection ic2 = cl.acceptConnection(serv);
				System.out.println("Cliente : Recebi...");
				
				IMessage im2 = new UdpIMessage();

				int j = ic2.receive(im2);

				byte[] bytes = new byte[j];

				System.arraycopy(im2.getBytes(), 0, bytes, 0, j);

				String respServidor = new String(bytes);
				String respServidorModified = "";
				for (int i = 0; i < respServidor.length(); i++) {
					if (new Character(respServidor.charAt(i))
							.isDigit(respServidor.charAt(i))
							|| new Character(respServidor.charAt(i))
									.isLetter(respServidor.charAt(i))
							|| respServidor.charAt(i) == ' '
							|| respServidor.charAt(i) == '.'
							|| respServidor.charAt(i) == ':') {
						respServidorModified = respServidorModified
								+ respServidor.charAt(i);
					}
				}
				im.getAreaJogo().append(respServidorModified + "\n");
				if(respServidorModified.equalsIgnoreCase("Iniciando...")){
					im.getJogadores().setText("");
					im.getJogadores().append(im.getJtfNick().getText() + " : " + InetAddress.getLocalHost());
				}
			}
			
			
			
			
			
			
			
			/*DatagramSocket clientSocket = new DatagramSocket(4567);
			while (true) {
				byte[] receiveData = new byte[1024];
				// declara o pacote a ser recebido
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);

				// recebe pacote do servidor
				System.out.println("Cliente : Aguardando resposta...");
				clientSocket.receive(receivePacket);
				System.out.println("Cliente : Recebi...");
				// separa somente o dado recebido
				// String modifiedSentence = new
				// String(receivePacket.getData());

				String respServidor = new String(receivePacket.getData());
				String respServidorModified = "";
				for (int i = 0; i < respServidor.length(); i++) {
					if (new Character(respServidor.charAt(i))
							.isDigit(respServidor.charAt(i))
							|| new Character(respServidor.charAt(i))
									.isLetter(respServidor.charAt(i))
							|| respServidor.charAt(i) == ' '
							|| respServidor.charAt(i) == '.'
							|| respServidor.charAt(i) == ':') {
						respServidorModified = respServidorModified
								+ respServidor.charAt(i);
					}
				}
				im.getAreaJogo().append(respServidorModified + "\n");
				if(respServidorModified.equalsIgnoreCase("Iniciando...")){
					im.getJogadores().append(im.getJtfNick().getText() + " : " + InetAddress.getLocalHost());
				}

			}*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enviarMsg(String msg, String ipServer) { // retorna resposta do servidor
		try {
			CommLayer cl = new UdpCommLayer();
			IConnection ic = cl.openConnection(InetAddress.getByName(ipServer), 9876);
			IMessage im = new UdpIMessage();
			im.setBytes(msg.getBytes());
			ic.send(im);
			
	    } catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getQtdePalitosMao() {
		return qtdePalitosMao;
	}

	public void setQtdePalitosMao(int qtdePalitosMao) {
		this.qtdePalitosMao = qtdePalitosMao;
	}

	public InetAddress getIpadress() {
		return ipadress;
	}

	public void setIpadress(InetAddress ipadress) {
		this.ipadress = ipadress;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getMsgServidor() {
		return msgServidor;
	}

	public void setMsgServidor(String msgServidor) {
		this.msgServidor = msgServidor;
	}

	public int getPontos() {
		return pontos;
	}

	public void setPontos(int pontos) {
		this.pontos = pontos;
	}

}
