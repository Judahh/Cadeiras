package protocolos.comm.tcp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import protocolos.comm.IConnection;
import protocolos.comm.Server;


class TcpServer implements Server {

	private ServerSocket serverSocket;

	public TcpServer(int porta) {
		try {
			serverSocket = new ServerSocket(porta);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public IConnection accept() {
		TcpIConnection retorno = null;
		try {
			Socket socket = serverSocket.accept();
			retorno = new TcpIConnection(socket);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return retorno;
	}
}
