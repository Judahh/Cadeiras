package protocolos.comm;

public interface IMessage {

	byte[] getBytes();

	int setBytes(byte[] data);

}
