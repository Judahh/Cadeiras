package protocolos.comm.tcp;

import protocolos.comm.IMessage;

public class TcpIMessage implements IMessage{

	private byte[] data = null;

	public byte[] getBytes() {
		return data;
	}

	public int setBytes(byte[] data) {
		this.data = data;
		return data.length;
	}


}
