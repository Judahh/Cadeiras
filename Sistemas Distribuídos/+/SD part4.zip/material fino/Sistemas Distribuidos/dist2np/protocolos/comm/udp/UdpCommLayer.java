package protocolos.comm.udp;

import java.net.InetAddress;

import protocolos.comm.CommLayer;
import protocolos.comm.IConnection;
import protocolos.comm.Server;


public class UdpCommLayer implements CommLayer{

	public IConnection acceptConnection(Server s) {
		return s.accept();
	}

	public Server createServer(int porta) {
		return new UdpServer(porta);
	}

	public IConnection openConnection(InetAddress hostAddress, int porta) {
		return new UdpIConnection(hostAddress, porta);
	}

}
