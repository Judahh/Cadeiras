package protocolos.comm;

public interface Server {

	IConnection accept();

}
