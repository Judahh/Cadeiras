package protocolos.comm.tcp;


import java.net.InetAddress;

import protocolos.comm.CommLayer;
import protocolos.comm.IConnection;
import protocolos.comm.Server;


public class TcpCommLayer implements CommLayer{

	public IConnection acceptConnection(Server s) {
		return s.accept();
	}

	public Server createServer(int porta) {
		return new TcpServer(porta);
	}

	public IConnection openConnection(InetAddress hostAddress, int porta) {
		return new TcpIConnection(hostAddress, porta);
	}

}
