package protocolos.comm;

import java.net.*;

public interface CommLayer {

	IConnection openConnection(InetAddress hostAdress, int porta);

	Server createServer(int porta);

	IConnection acceptConnection(Server s);

}
