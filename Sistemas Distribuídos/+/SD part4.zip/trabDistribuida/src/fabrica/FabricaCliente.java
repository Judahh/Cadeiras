package fabrica;

import java.net.InetAddress;
import cliente.*;

public abstract class FabricaCliente {
	
	private static ClienteAbstrato protocolo;
	
	public static ClienteAbstrato criarConexao(int tipo, InetAddress endereco, int porta){
		
		switch (tipo) {
		case 1:
			protocolo = new ClienteTCP(endereco, porta);
			break;
		case 2:
			protocolo = new ClienteUDP(endereco, porta);
			break;
		}
		
		return protocolo;
		
	}

}
