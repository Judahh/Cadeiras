package fabrica;

import servidor.*;

public abstract class FabricaServidor {
	
	private static ServidorAbstrato servidor;
	
	public static ServidorAbstrato createServer(int tipo, int porta){
		
		switch (tipo) {
		case 1:
			servidor = new ServidorTCP(porta);
			break;
		case 2:
			servidor = new ServidorUDP(porta);
			break;
		}
		
		return servidor;
		
	}

}
