package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import cliente.*;

public class ServidorTCP extends ServidorAbstrato {
	
	private ServerSocket serverSocket;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	private Socket clientSocket;

	public ServidorTCP(int porta) {
		super(porta);
		try {
			serverSocket = new ServerSocket(porta);
		} catch (Exception e) {
			System.out.println("Erro ao obter um ServerSocket. Erro: "
					+ e.getMessage());
		}
	}

	@Override
	public ClienteAbstrato aceitaConexao() throws IOException {
		
		ClienteAbstrato cliente = null;
		
		while(true){
			
			clientSocket = serverSocket.accept();
			
			dataInputStream = new DataInputStream(clientSocket.getInputStream());
			dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
			
			String mensagem = dataInputStream.readUTF();
			
//			processa(mensagem);
			
			cliente = new ClienteTCP(clientSocket.getInetAddress(), clientSocket.getLocalPort());
			
			return cliente;
			
		}
		
	}
	
	@Override
	public void enviaMsg(String mensagem) throws IOException {
		
		dataOutputStream.writeUTF(mensagem);
	}

}