package servidor;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import cliente.*;

public class ServidorUDP extends ServidorAbstrato {
	
	private DatagramPacket packet;
	private DatagramSocket datagramSocket;
	
	public ServidorUDP(int porta) {
		super(porta);
	}

	@Override
	public ClienteAbstrato aceitaConexao() throws IOException {
		
		datagramSocket = new DatagramSocket(porta);
		
		while(true){
			
			byte[] buffer = new byte[1000];
			packet = new DatagramPacket(buffer, buffer.length);
			datagramSocket.receive(packet);
			
//			processa(getDadosValidos(packet));
			
//			AbstractConnector abstractConnector = new UDPConnectorImpl(packet.getAddress(), packet.getPort());
//			return abstractConnector;
			
		}
		
	}
	
	@Override
	public void enviaMsg(String mensagem) throws IOException {
		byte[] bufferR = mensagem.getBytes();
		DatagramPacket datagramPacket = new DatagramPacket(bufferR, bufferR.length, packet.getAddress(), packet.getPort());
		datagramSocket.send(datagramPacket);
	}

}