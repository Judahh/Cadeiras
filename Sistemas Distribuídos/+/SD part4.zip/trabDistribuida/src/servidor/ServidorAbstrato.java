package servidor;

import java.io.IOException;

import cliente.*;

public abstract class ServidorAbstrato {
	
	protected int porta;
	
	public ServidorAbstrato(int porta){
		this.porta = porta;
	}
	
	public abstract ClienteAbstrato aceitaConexao()throws IOException;
	public abstract void enviaMsg(String mensagem) throws IOException;
	
}
