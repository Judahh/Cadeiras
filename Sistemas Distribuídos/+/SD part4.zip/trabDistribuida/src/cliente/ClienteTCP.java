package cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

public class ClienteTCP extends ClienteAbstrato {
	
	private Socket clienteSocket;
	
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
	public ClienteTCP(InetAddress endereco, int porta) {
		
		super(endereco, porta);
		
		try{
			// Criando o socket de acordo com os par�metros especificados
			clienteSocket = new Socket(endereco, porta);
			
			// Criando um canal (Buffer) para receber os dados
			dataInputStream = new DataInputStream(clienteSocket.getInputStream());
			
			// Criando um canal para enviar os dados
			dataOutputStream = new DataOutputStream(clienteSocket.getOutputStream());
			
			
		}catch(Exception e){
			System.out.println("Erro ao obter um socket. Erro: " + e.getMessage());
		}
	}

	@Override
	public String recebeMsg() throws IOException {
		return dataInputStream.readUTF();
	}

	@Override
	public void enviaMsg(String mensagem) throws IOException {
		dataOutputStream.writeUTF(mensagem);
		dataOutputStream.flush();
				
	}
	
}