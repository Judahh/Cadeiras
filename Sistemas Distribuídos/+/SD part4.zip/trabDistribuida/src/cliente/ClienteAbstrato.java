package cliente;

import java.io.IOException;
import java.net.InetAddress;

public abstract class ClienteAbstrato {
	
	protected InetAddress endereco;
	protected int porta;
	
	public ClienteAbstrato(InetAddress endereco, int porta){
		this.endereco = endereco;
		this.porta = porta;
	}
	
	public abstract void enviaMsg(String mensagem) throws IOException;
	public abstract String recebeMsg() throws IOException;
		
	
}