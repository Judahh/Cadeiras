package cliente;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

public class ClienteUDP extends ClienteAbstrato {

	private InetAddress server;
	private int porta;
	private DatagramSocket datagramSocket;

	public ClienteUDP(InetAddress endereco, int porta) {
		super(endereco, porta);
		this.server = endereco;
		this.porta = porta;
	}

	@Override
	public String recebeMsg() throws IOException {
		byte[] buffer = new byte[1000];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		datagramSocket.receive(packet);
		return getDadosValidos(packet);
	}

	@Override
	public void enviaMsg(String mensagem) throws IOException {
		datagramSocket = new DatagramSocket();
		byte[] data = mensagem.getBytes();
		DatagramPacket packet = new DatagramPacket(data, data.length, server, porta);
		datagramSocket.send(packet);
	}

	public static String getDadosValidos(DatagramPacket datagramPacket) {

		if (datagramPacket == null) {
			return "";
		}

		ArrayList<Byte> bytesValidos = new ArrayList<Byte>();

		for (byte bytes : datagramPacket.getData()) {
			if (bytes == 0) {
				break;
			}
			bytesValidos.add(bytes);
		}

		byte[] bytes = new byte[bytesValidos.size()];

		for (int i = 0; i < bytesValidos.size(); i++) {
			bytes[i] = bytesValidos.get(i);
		}

		return new String(bytes);
	}

}