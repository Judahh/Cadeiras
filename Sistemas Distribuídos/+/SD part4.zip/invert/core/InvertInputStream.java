package br.com.sistemadistribuido.invert.core;

import java.io.IOException;
import java.io.InputStream;

public class InvertInputStream extends InputStream {

    /**
     * InputStream que ser� invertido
     */
    private InputStream inputStream;

    /**
     * Construtor da classe
     *
     * @param inputStream O InputStream que ser� invertido
     */
    public InvertInputStream(final InputStream inputStream) {
        this.inputStream = inputStream;
    }

    /**
     * L� o pr�ximo byte de dados do outputStream.
     *
     * @param b O byte a ser lido
     */
    @Override
    public int read() throws IOException {
        return inputStream.read();
    }

    /**
     * L� um determinado n�mero de bytes do inputStream e armazena-os em um
     * array de buffer bytes.
     *
     * @param bytes O Array de bytes de ser lido
     * @return O n�mero total de bytes lidos no buffer, ou -1 se n�o houver
     * mais dados, porque o fim do fluxo foi atingido.
     */
    @Override
    public int read(final byte[] bytes) throws IOException {
        return read(bytes, 0, bytes.length - 1);
    }

    /**
     * L� bytes do array de bytes de forma invertida. Faz o for
     * do fim do array at� o in�cio, ou seja, percorre o array de forma
     * invertida.
     * at� len bytes de dados do fluxo de entrada em um array de bytes.
     *
     * @param bytes O Array de bytes a ser lido
     * @param inicio A posi��o de in�cio que vai come�ar a ler
     * @param fim A posi��o de fim que vai come�ar a ler
     * @return Uma estimativa do n�mero de bytes que pode ser lido a partir
     * deste fluxo de entrada sem bloquear ou 0 quando chega o fim do fluxo de entrada.
     */
    @Override
    public int read(final byte[] bytes, final int inicio, final int fim) throws IOException {

        //Quantidade total de bytes
        int bytesCount = 0;

        //Vari�veis de controle para evitar ArrayIndexOutOfBoundsException
        int realFim = fim;
        int realInicio = inicio;

        //Verificando se o usu�rio passou um fim maior que o tamanho m�ximo permitido
        if (realFim + inicio > bytes.length - 1) {
            realFim = bytes.length - 1 - inicio;
        }

        //Verificando se o usu�rio passou um in�cio menor que 0
        if (realInicio < 0) {
            realInicio = 0;
        }

        //Percorrendo o Array de Bytes de forma invertida
        for (int i = realFim; i >= realInicio; i--) {
            //Lendo o byte
            bytes[i] = (byte) read();
            bytesCount++;
        }

        return bytesCount;
    }
}
