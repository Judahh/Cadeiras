package br.com.sistemadistribuido.invert.teste;

import java.io.IOException;


import br.com.sistemadistribuido.invert.core.InvertOutputStream;


public class TestInvertOutputStream {

    private InvertOutputStream invertOutputStream;

    /**
     * M�todo que carrega as informa��es iniciais.
     */
    @Before
    public void init(){
        invertOutputStream = new InvertOutputStream(System.out);
    }

    @Test
    public void testWrite() throws IOException{
        final String texto = "Sistema Distribu�do";
        System.out.println("Texto Normal: Sistema Distribu�do");
        System.out.println("Deveria ser impresso: od�ubirtsiD ametsiS");
        System.out.print("Texto invertido: ");
        invertOutputStream.write(texto.getBytes());
        invertOutputStream.flush();

    }

}
