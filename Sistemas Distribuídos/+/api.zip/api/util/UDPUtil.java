package br.com.sistemadistribuido.api.util;

import java.net.DatagramPacket;
import java.util.ArrayList;

public class UDPUtil {
	
	private UDPUtil(){
		
	}
	
	public static String getDadosValidos(DatagramPacket datagramPacket){
		
		if (datagramPacket == null) {
			return "";
		}

		ArrayList<Byte> bytesValidos = new ArrayList<Byte>();

		for (byte bytes : datagramPacket.getData()) {
			if (bytes == 0) {
				break;
			}
			bytesValidos.add(bytes);
		}

		byte[] bytes = new byte[bytesValidos.size()];

		for (int i = 0; i < bytesValidos.size(); i++) {
			bytes[i] = bytesValidos.get(i);
		}

		return new String(bytes);
	}

}
