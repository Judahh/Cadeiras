package br.com.sistemadistribuido.api.core.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;

import br.com.sistemadistribuido.api.util.Util;

public class TCPConnectorImpl extends AbstractConnector {
	
	private Socket clientSocket;
	
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
	public TCPConnectorImpl(InetAddress endereco, int porta) {
		
		super(endereco, porta);
		
		try{
			// Criando o socket de acordo com os par�metros especificados
			clientSocket = new Socket(endereco, porta);
			
			// Criando um canal (Buffer) para receber os dados
			dataInputStream = new DataInputStream(clientSocket.getInputStream());
			
			// Criando um canal para enviar os dados
			dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
			
			
		}catch(Exception e){
			System.out.println("Erro ao obter um socket. Erro: " + e.getMessage());
		}
	}

	@Override
	public String recebeMsg() throws IOException {
		return dataInputStream.readUTF();
	}

	@Override
	public void enviaMsg(String mensagem) throws IOException {
		dataOutputStream.writeUTF(mensagem);
		dataOutputStream.flush();
				
	}
	
	@Override
	public void enviaFile(File arquivo) throws IOException {
		
		Date dataAtualizacao = new Date();
		
		Util.atualizaCache(arquivo.getName(), dataAtualizacao);
		
		DataInputStream input = new DataInputStream(new FileInputStream(arquivo));  
		
		//Avisando que vai enviar um arquivo
		dataOutputStream.writeUTF("PUTFILE " + arquivo.getName() + " " + 
				dataAtualizacao.getTime());
		
		//Enviando o arquivo
		byte[] cache = new byte[10240];   
        int size = 0;   
        while ((size = input.read(cache)) > -1) {
        	dataOutputStream.write(cache, 0, size);   
        }
        
        input.close();
        dataInputStream.close();  
        dataOutputStream.close(); 
		
	}

	@Override
	public File recebeFile() throws IOException {
		
		String mensagem =  dataInputStream.readUTF();
		
		String [] mensagens = mensagem.split(" ");
		
		String nomeArquivo = mensagens[1];
		
		Date dataAtualizacao = new Date(Long.parseLong(mensagens[2]));
		
		Util.atualizaCache(nomeArquivo, dataAtualizacao);
		
		System.out.println("Recebendo do Servidor o arquivo: " + nomeArquivo);
		
		String inFile = Util.pathCliente + nomeArquivo;

		DataOutputStream output = new DataOutputStream(new FileOutputStream(inFile));

		// Montando o arquivo
		int readByte = dataInputStream.read();
		while (readByte != -1) {
			output.write((byte) readByte);
			readByte = dataInputStream.read();
		}
		
		output.close();
		output.flush();
		
		return null;
	}

}
