package br.com.sistemadistribuido.api.core.factory;

import java.net.InetAddress;

import br.com.sistemadistribuido.api.core.client.AbstractConnector;
import br.com.sistemadistribuido.api.core.client.TCPConnectorImpl;
import br.com.sistemadistribuido.api.core.client.UDPConnectorImpl;

public abstract class ConnectorFactory {
	
	private static AbstractConnector abstractConnector;
	
	public static AbstractConnector createConnector(int tipo, InetAddress endereco, int porta){
		
		switch (tipo) {
		case 1:
			abstractConnector = new TCPConnectorImpl(endereco, porta);
			break;
		case 2:
			abstractConnector = new UDPConnectorImpl(endereco, porta);
			break;
		}
		
		return abstractConnector;
		
	}

}
