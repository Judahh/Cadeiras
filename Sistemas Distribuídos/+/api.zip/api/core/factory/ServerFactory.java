package br.com.sistemadistribuido.api.core.factory;

import br.com.sistemadistribuido.api.core.server.AbstractServer;
import br.com.sistemadistribuido.api.core.server.TCPServerImpl;
import br.com.sistemadistribuido.api.core.server.UDPServerImpl;

public abstract class ServerFactory {
	
	private static AbstractServer abstractServer;
	
	public static AbstractServer createServer(int tipo, int porta){
		
		switch (tipo) {
		case 1:
			abstractServer = new TCPServerImpl(porta);
			break;
		case 2:
			abstractServer = new UDPServerImpl(porta);
			break;
		}
		
		return abstractServer;
		
	}

}
