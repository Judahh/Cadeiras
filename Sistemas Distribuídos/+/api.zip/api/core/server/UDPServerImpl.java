package br.com.sistemadistribuido.api.core.server;
import static br.com.sistemadistribuido.api.util.UDPUtil.getDadosValidos;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Date;

import br.com.sistemadistribuido.api.core.client.AbstractConnector;
import br.com.sistemadistribuido.api.util.CacheArquivo;
import br.com.sistemadistribuido.api.util.Util;

public class UDPServerImpl extends AbstractServer {
	
	private DatagramPacket packet;
	private DatagramSocket datagramSocket;
	
	public UDPServerImpl(int porta) {
		super(porta);
	}

	@Override
	public AbstractConnector aceitaConexao() throws IOException {
		
		datagramSocket = new DatagramSocket(porta);
		
		while(true){
			
			byte[] buffer = new byte[1000];
			packet = new DatagramPacket(buffer, buffer.length);
			datagramSocket.receive(packet);
			
			processa(getDadosValidos(packet));
			
//			AbstractConnector abstractConnector = new UDPConnectorImpl(packet.getAddress(), packet.getPort());
//			return abstractConnector;
			
		}
		
	}
	
	@Override
	public void getFile(String nomeArquivo) throws IOException {
		
		String path = Util.pathServidor;
		
		System.out.println("Host solicitou o arquivo " + nomeArquivo);
		
		path += nomeArquivo;
        
		File arquivo = new File(path);
		
		CacheArquivo cacheArquivo = Util.getCacheArquivo(nomeArquivo);
		
		//Avisando que vai enviar um arquivo
		datagramSocket = new DatagramSocket();
		byte[] data = ("PUTFILE " + arquivo.getName() +  " " 
				+ cacheArquivo.getDataAtualizacao().getTime()).getBytes();
		
		DatagramPacket datagramPacket = new DatagramPacket(data, data.length, packet.getAddress(), packet.getPort());
		datagramSocket.send(datagramPacket);
		
		byte[] dataFile = Util.getBytesFromFile(arquivo);
		DatagramPacket packetFile = new DatagramPacket(dataFile, dataFile.length, packet.getAddress(), packet.getPort());
		
		datagramSocket.send(packetFile);
		
	}

	@Override
	public void putFile(String nomeArquivo, String data) throws IOException {
		
		Date dataAtualizacao = new Date(Long.parseLong(data));
		
		System.out.println("Recebendo do Host: " + datagramSocket.getInetAddress() +
				" o arquivo " + nomeArquivo);
		
		Util.atualizaCache(nomeArquivo, dataAtualizacao);
		
		String inFile = Util.pathServidor + nomeArquivo;
		File file = new File(inFile);
		
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		
		byte[] buffer = new byte[1000];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

		datagramSocket.receive(packet);
		
		fileOutputStream.write(packet.getData());
		
		fileOutputStream.close();
		fileOutputStream.flush();
		
	}

	@Override
	public void sendMsg(String mensagem) throws IOException {
		byte[] bufferR = mensagem.getBytes();
		DatagramPacket datagramPacket = new DatagramPacket(bufferR, bufferR.length, packet.getAddress(), packet.getPort());
		datagramSocket.send(datagramPacket);
	}

}
