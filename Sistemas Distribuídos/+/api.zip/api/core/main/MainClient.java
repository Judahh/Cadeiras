package br.com.sistemadistribuido.api.core.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.Date;

import br.com.sistemadistribuido.api.core.client.AbstractConnector;
import br.com.sistemadistribuido.api.core.factory.ConnectorFactory;
import br.com.sistemadistribuido.api.util.CacheArquivo;
import br.com.sistemadistribuido.api.util.Util;

public class MainClient {

	private static int opcaoMenuRaiz;
	private static int opcaoMenuSecundario;
	
	private static String nomeArquivo;

	public static void main(String[] args) throws IOException {

		opcaoMenuRaiz = capturaOpcaoUsuarioMenuRaiz();

		if(opcaoMenuRaiz != 1 && opcaoMenuRaiz != 2){
		    return;
		}

		opcaoMenuSecundario = capturaOpcaoUsuarioMenuSecundario();
		
		while(opcaoMenuSecundario != 4){
			processa();
			opcaoMenuSecundario = capturaOpcaoUsuarioMenuSecundario();
		}
		
	}

	private static void processa() throws IOException {
		
		InetAddress inetAddress = InetAddress.getByName(Util.HOST);

		AbstractConnector abstractConnector = ConnectorFactory.createConnector(opcaoMenuRaiz, inetAddress, Util.PORTA);
		
		//Obtendo a lista de arquivos
		if(opcaoMenuSecundario == 1){
			getList(abstractConnector);
		}
		
		//Solicitando arquivo
		if(opcaoMenuSecundario == 10){
			getFile(abstractConnector);
		}
		
		//Enviando arquivo
		if(opcaoMenuSecundario == 3){
			putFile(abstractConnector);
		}
		
		//Solicitando arquivo
		if(opcaoMenuSecundario == 2){
			getCacheArquivo(abstractConnector);
		}
		
	}
	
	private static void getCacheArquivo(AbstractConnector abstractConnector) throws IOException {
		
		System.out.println("Solicitando um recurso ao servidor...");
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Digite o nome do arquivo a ser buscado:\n");
        
        System.out.println(stringBuilder);
        
        nomeArquivo = in.readLine();
        
        abstractConnector.enviaMsg("GETCACHE " + nomeArquivo);
        
        String resposta = abstractConnector.recebeMsg();
        
        if(resposta.equals("")){
        	System.out.println("Servidor n�o possui o recurso solicitado...");
        }else{
        	Date dataAtualizacao = new Date(Long.parseLong(resposta));
        	CacheArquivo cacheArquivo = Util.getCacheArquivo(nomeArquivo);
        	
        	if(cacheArquivo == null){
        		System.out.println("Esta��o n�o possui cache para esse recurso...");
        		System.out.println("Ser� necess�rio solicitar o recurso");
        		opcaoMenuSecundario = 10;
        		processa();
        	}else{
    			if(cacheArquivo.getDataAtualizacao().compareTo(dataAtualizacao) >= 0){
    				System.out.println("Arquivo local atualizado...");
    				System.out.println("N�o ser� necess�rio solicitar o recurso");
    			}else{
    				System.out.println("Arquivo do servidor mais atualizado...");
    				System.out.println("Ser� necess�rio solicitar o recurso");
    				opcaoMenuSecundario = 10;
            		processa();
    			}
        	}
        	
        }
		
	}

	private static void getFile(AbstractConnector abstractConnector) throws IOException {
		abstractConnector.enviaMsg("GETFILE " + nomeArquivo);
		abstractConnector.recebeFile();
	}

	private static void getList(AbstractConnector abstractConnector) throws IOException{
		
		System.out.println("Solicitando a lista de arquivos...");
		abstractConnector.enviaMsg("GETLIST");
		String resposta = abstractConnector.recebeMsg();
		
		if(resposta.isEmpty()){
			System.out.println("Sem arquivo no servidor!");
		}else{
			String[] listaArquivos = resposta.split(" ");
			System.out.println("Lista recebida...");
			
			for(String nomeArquivo : listaArquivos){
				System.out.println(nomeArquivo);
			}
		}
	}
	
	private static void putFile(AbstractConnector abstractConnector) throws IOException{
		
		String path = Util.pathCliente;
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Digite o nome do arquivo a ser enviado:\n");
        
        System.out.println(stringBuilder);
        
        nomeArquivo = in.readLine();
        
        path += nomeArquivo;
        
		File arquivo = new File(path);  
		abstractConnector.enviaFile(arquivo);
	}

	private static int capturaOpcaoUsuarioMenuSecundario() throws NumberFormatException, IOException {
		exibeMenuSecundario();
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		return Integer.parseInt(in.readLine());
	}
	
	private static int capturaOpcaoUsuarioMenuRaiz() throws NumberFormatException, IOException  {
        exibeMenuRaiz();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        return Integer.parseInt(in.readLine());
    }

    private static void exibeMenuRaiz() {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Escolha a op��o desejada:\n");
        stringBuilder.append("[1] - Cria Cliente Socket TCP\n");
        stringBuilder.append("[2] - Cria Cliente Socket UDP\n");
        stringBuilder.append("[3] - Sair\n");
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Op��o:");

        System.out.println(stringBuilder);

    }
    
    private static void exibeMenuSecundario() {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Escolha a op��o desejada:\n");
        stringBuilder.append("[1] - Obter lista de Arquivos\n");
        stringBuilder.append("[2] - Solicitar Arquivo\n");
        stringBuilder.append("[3] - Enviar/Atualizar Arquivo\n");
        stringBuilder.append("[4] - Sair\n");
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Op��o:");

        System.out.println(stringBuilder);

    }

}
