package br.com.sistemadistribuido.original;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Main {
	public static void main(String[] args) throws UnknownHostException, IOException {

		Socket s = new Socket("www.tiagorolim.com",80);
		OutputStream ous = s.getOutputStream();
		OutputStreamWriter ousw = new OutputStreamWriter(ous);

		InputStream is = s.getInputStream();

		ousw.write("HEAD http://www.tiagorolim.com/2009/06/entendendo-o-ciclo-de-vida-jsf.html HTTP/1.0\r\n\n");

//		ousw.write("GET http://www.tiagorolim.com/2009/06/entendendo-o-ciclo-de-vida-jsf.html HTTP/1.0\r\n\n");
//		ousw.write("GET http://www.noalvopaintball.com.br/estrutura.php HTTP/1.0\r\n\n");
//		ousw.write("TRACE http://www.noalvopaintball.com.br/index.htm HTTP/1.0\r\n\n");
		ousw.flush();

		int read;
		while((read = is.read())!= -1){
			System.out.print((char)read);
		}

	}
}
