package br.com.sistemadistribuido.original;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

	// Cria um ServerSocket acoplado � porta 1024
	ServerSocket server = new ServerSocket(1050);

	public Servidor(String dados) throws IOException {
		Socket cliente;
		// Cria um ServerSocket acoplado � porta 1024
		// La�o para tratamento de conex�es
		while (true) {
			cliente = server.accept();
			System.out.println(cliente.getLocalPort());

			// Obt�m canal de recebimento de dados
			InputStream in = cliente.getInputStream();

			int read=0;
			while((read=in.read())!=-1){
				System.out.print((char)read);
			}
			System.out.println();

		}

	}

	public static void main(String[] args) {

		try {
			Servidor serv = new Servidor("isso � um teste");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
