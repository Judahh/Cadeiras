package br.com.sistemadistribuido.api.core.client;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

public abstract class AbstractConnector {
	
	protected InetAddress endereco;
	protected int porta;
	
	public AbstractConnector(InetAddress endereco, int porta){
		this.endereco = endereco;
		this.porta = porta;
	}
	
	public abstract void enviaMsg(String mensagem) throws IOException;
	public abstract String recebeMsg() throws IOException;
	public abstract void enviaFile(File arquivo) throws IOException;
	public abstract File recebeFile() throws IOException;
	
	
}
