package br.com.sistemadistribuido.compactador.util;

import java.util.Date;

import org.joda.time.Period;
import org.joda.time.format.PeriodFormatter;
import org.joda.time.format.PeriodFormatterBuilder;

public class DateUtil {

	private DateUtil() {

	}

	public static String exibeEmHoras(Date dataHoraInicio, Date dataHoraFim) {

		Period period = new Period(dataHoraInicio.getTime(), dataHoraFim
				.getTime());

		PeriodFormatter periodFormatter = new PeriodFormatterBuilder()
				.printZeroAlways().appendDays().appendSuffix(" dia", " dias")
				.appendSeparator(", ").minimumPrintedDigits(2).appendHours()
				.appendSeparator(":").appendMinutes().appendSeparator(":")
				.appendSeconds().appendSeparator(".").appendMillis3Digit()
				.toFormatter();

		return periodFormatter.print(period);

	}

}
