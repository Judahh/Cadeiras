package br.com.sistemadistribuido.original;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientNew {  
   
    public static void main(String[] args) {
    	
       int port = 1025;  
       InetAddress ia = null;
       
       try {     
          ia = InetAddress.getLocalHost();     
       } catch (UnknownHostException e) {     
          e.printStackTrace();     
       }     
   
       String IP = "192.168.0.164";  
       String outFile = "C:\\testeCliente.txt";  
       try {  
          Socket MyCliente = new Socket(IP,port);  
   
          File file = new File(outFile);  
   
          DataInputStream input = new DataInputStream(new FileInputStream(file));  
   
          DataInputStream inputMsg = new DataInputStream(MyCliente.getInputStream());  
          DataOutputStream outputMsg = new DataOutputStream(MyCliente.getOutputStream());  
   
          outputMsg.writeUTF("testeCliente.txt");
   
          byte[] cache = new byte[10240];   
          int size = 0;   
          while ((size = input.read(cache)) > -1) {
        	  outputMsg.write(cache, 0, size);   
          }
   
          inputMsg.close();  
          outputMsg.close();  
          input.close();  
          MyCliente.close();  
          
       } catch (Exception e) {  
          System.err.println(e.toString());  
       }  
    }
    
 }  
