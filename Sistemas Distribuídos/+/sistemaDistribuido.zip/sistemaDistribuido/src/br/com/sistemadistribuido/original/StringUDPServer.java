package br.com.sistemadistribuido.original;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;


public class StringUDPServer extends StringServer {
	private int port;	

	public StringUDPServer(int port) {
		super(port);
		this.port = port;	
	}

	@Override
	StringConnector acceptConnector() throws IOException {
		byte[] buffer = new byte[1000];
		DatagramSocket datagramSocket = new DatagramSocket(this.port);
		DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
		datagramSocket.receive(packet);
		
		StringUDPConnector stringUDPConnector = new StringUDPConnector(packet.getAddress(), packet.getPort());
		
		return stringUDPConnector;

	}

}
