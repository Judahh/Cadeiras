package br.com.sistemadistribuido.api.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Util {
	
	private static List<CacheArquivo> listaCacheArquivo;
	
	public static final String pathCliente = "/Users/laioviana/c/";
	public static final String pathServidor ="/Users/laioviana/s";
	
	public static final int PORTA = 1030;
	
	public static final String HOST = "localhost";

	public static void atualizaCache(String nomeArquivo, Date dataAtualizacao){
		
		CacheArquivo cacheArquivo = getCacheArquivo(nomeArquivo);
		
		//Atualizando as informa��es sobre o cache
		if(cacheArquivo != null){
			cacheArquivo.setDataAtualizacao(dataAtualizacao);
		}else{
			CacheArquivo cacheArquivoAux = new CacheArquivo();
			cacheArquivoAux.setDataAtualizacao(dataAtualizacao);
			cacheArquivoAux.setNomeArquivo(nomeArquivo); 
			getListaCacheArquivo().add(cacheArquivoAux);
		}
		
	}
	
	public static List<CacheArquivo> getListaCacheArquivo(){
		
		if (listaCacheArquivo == null) {
			listaCacheArquivo = new ArrayList<CacheArquivo>();
		}

		listaCacheArquivo.clear();
		
		File[] listaArquivos = new File(pathCliente).listFiles();

		if (listaArquivos != null && listaArquivos.length > 0) {
			for (File arquivo : listaArquivos) {
				CacheArquivo ca = new CacheArquivo();
				ca.setNomeArquivo(arquivo.getName());
				listaCacheArquivo.add(ca);
			}

		}
		
		return listaCacheArquivo;
	}
	
	public static CacheArquivo getCacheArquivo(String nomeArquivo){
		
		CacheArquivo cacheArquivo = null;
		
		for(CacheArquivo arquivo : getListaCacheArquivo()){
			if(arquivo.getNomeArquivo().equals(nomeArquivo)){
				cacheArquivo = arquivo;
				break;
			}
		}
		
		return cacheArquivo;
		
	}
	
	// Returns the contents of the file in a byte array.
    public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        // You cannot create an array using a long type.
        // It needs to be an int type.
        // Before converting to an int type, check
        // to ensure that file is not larger than Integer.MAX_VALUE.
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    }
	
}
