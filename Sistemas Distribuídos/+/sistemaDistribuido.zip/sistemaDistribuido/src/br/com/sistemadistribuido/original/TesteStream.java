package br.com.sistemadistribuido.original;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;

public class TesteStream {

    public static void main(final String[] args) {
        try {
            testWriter();
            System.out.println();
//            testReader();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }

    private static void testWriter() throws IOException {
        final String teste = "PEDRO Ciarlini\r\n";
        final OutputStreamWriter osw = new OutputStreamWriter(System.out);
        final CipherWriter cw = new CipherWriter(osw);
        cw.write(teste);
        cw.flush();
    }

    private static void testReader() throws IOException {
        final String teste = "QIFSU Doesmopo\r\n";
        final char temp[] = new char[16];
        final InputStreamReader isr = new InputStreamReader(System.in);
        final CipherReader cw = new CipherReader(isr);
        cw.read(temp);
        System.out.println(Arrays.toString(temp));
    }

    private static void testStreams1() throws IOException {
        final String teste = "TESTE1234\n";
        final InvertOutputStream ios = new InvertOutputStream(System.out);
        System.out.write("TESTE1234".getBytes());
        System.out.flush();

        ios.write(teste.getBytes());
        ios.flush();
        System.out.println();
        System.out.println();
        final InvertInputStream iis = new InvertInputStream(System.in);
        final byte[] b = new byte[5];
        while (true) {
            System.out.println("Digite caracteres para sair.");
            iis.read(b);
            // System.out.println(Arrays.toString(b));
            System.out.println(new String(b));
            // System.out.println("Digite 'A' para sair.");
            // int baite = iis.read();
            // if (baite == 65) break;
        }
    }
}
