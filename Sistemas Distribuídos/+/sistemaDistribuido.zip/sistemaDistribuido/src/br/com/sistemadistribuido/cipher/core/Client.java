package br.com.sistemadistribuido.cipher.core;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import javax.swing.JOptionPane;

/**
 * Classe de texte para as Classes CipherReader e
 * CipherWriter
 *
 * @author Tiago, Samira e Romulo
 * @since 31/08/2009
 */
public class Client {

    public static void main(final String[] args) {

        try {

            //Montando o menu
            final StringBuilder menu = new StringBuilder();
            menu.append("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\n");
            menu.append("------------- Menu do Sistema -----------\n");
            menu.append("[1] - Cifrar usando o CipherWriter\n");
            menu.append("[2] - Decifrar usando o CipherReader\n");
            menu.append("[3] - Cifrar usando o CipherReader e decifrar usnado o CipherWriter\n");
            menu.append("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

            final String opcao = JOptionPane.showInputDialog(menu.toString());

            if (opcao.equals("1")) {
                testCipherWriter();
            } else if (opcao.equals("2")) {
                testCipherReader();
            } else if (opcao.equals("3")) {
                testCipherWriterAndCipherReader();
            }

        } catch (final IOException e) {
            System.out.println("Ocorreu um erro de IO");
        }
    }

    private static void testCipherWriter() throws IOException {

        System.out.println("\nX--------------------------- Testando o CipherWriter ----------------------------X\n ");

        System.out.print("Digite o Texto a ser cifrado pelo CipherWriter: [5 caracteres]");

        final char temp[] = new char[5];

        final InputStreamReader inputStreamReader = new InputStreamReader(System.in);

        inputStreamReader.read(temp);

        System.out.print("Texto cifrado: ");

        // Escrevendo o texto de forma cifrada
        final OutputStreamWriter osw = new OutputStreamWriter(System.out);
        final CipherWriter cipherWriter = new CipherWriter(osw);
        cipherWriter.write(temp);
        cipherWriter.flush();
    }

    private static void testCipherReader() throws IOException {

        System.out.println("\nX--------------------------- Testando o CipherReader ----------------------------X\n ");

        System.out.print("Digite o Texto a ser decifrado pelo CipherReader: [5 caracteres]");

        final char temp[] = new char[5];

        // Lendo o texto de forma cifrada
        final InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        final CipherReader cipherReader = new CipherReader(inputStreamReader);
        cipherReader.read(temp);

        System.out.print("Texto cifrado: ");

        System.out.println(temp);
    }

    private static void testCipherWriterAndCipherReader() throws IOException {

        System.out
                  .println("\nX--------------------- Testando o CipherReader e o CipherWriter -----------------------X\n ");

        System.out.print("Digite o Texto a ser cifrado pelo CipherReader \n"
                         + "e decifrado pelo CipherWriter: [5 caracteres]");

        final char temp[] = new char[5];

        // Lendo o texto de forma cifrada
        final InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        final CipherReader cipherReader = new CipherReader(inputStreamReader);
        cipherReader.read(temp);

        System.out.print("Texto normal: ");

        // Escrevendo o texto de forma decifrada
        final OutputStreamWriter osw = new OutputStreamWriter(System.out);
        final CipherWriter cipherWriter = new CipherWriter(osw);
        cipherWriter.write(temp);
        cipherWriter.flush();

    }

}
