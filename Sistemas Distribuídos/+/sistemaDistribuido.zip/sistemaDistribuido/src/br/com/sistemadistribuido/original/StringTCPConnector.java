package br.com.sistemadistribuido.original;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;


public class StringTCPConnector extends StringConnector {
	private Socket clientSocket;
	private BufferedReader buffer;
	private PrintWriter output;

	public StringTCPConnector(InetAddress address, int port) {
		super(address, port);
		try{
			// Criando o socket de acordo com os par�metros especificados
			clientSocket = new Socket(address,port);
			
			// Criando um canal (Buffer) para receber os dados
			buffer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			
			// Criando um canal para enviar os dados
			output = new PrintWriter(clientSocket.getOutputStream());			
			
			
		}catch(Exception e){
			System.out.println("Erro ao obter um socket. Erro: " + e.getMessage());
		}
		
	}

	@Override
	String receive() throws IOException {
		String result = "";
		int i;
		if (buffer != null){
			while ((i = buffer.read()) != - 1){
				char c = (char)i;
				result = result + c;
			}
		}
		return result;
	}

	@Override
	void send(String msn) throws IOException {
		if (output != null){
			output.print(msn);
			output.flush();
		}
	}
	
	public InputStream getInputStreamTCPConnector(){
		InputStream result = null;
		if (clientSocket != null){
			try{
				result = clientSocket.getInputStream();
			}catch(Exception e){
				System.out.println("Erro ao obter um InputStreamTCPConnector. Erro: " + e.getMessage());
			}
		}
		return result;
	}
	public OutputStream getOutputStreamTCPConnector(){
		OutputStream result = null;
		if (clientSocket != null){
			try{
				result = clientSocket.getOutputStream();				
			}catch(Exception e){
				System.out.println("Erro ao obter um OutputStreamTCPConnector. Erro: " + e.getMessage());								
			}
		}
		return result;
	}

	
}
