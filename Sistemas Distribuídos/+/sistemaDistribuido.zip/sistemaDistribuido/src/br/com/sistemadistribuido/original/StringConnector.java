package br.com.sistemadistribuido.original;

import java.io.IOException;
import java.net.InetAddress;


public abstract class StringConnector {
	private InetAddress address;
	private int port;
	public StringConnector(InetAddress address, int port){
		this.address = address;
		this.port = port;
	}
	abstract void send(String msn) throws IOException;
	abstract String receive() throws IOException;
}
