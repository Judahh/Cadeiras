package br.com.sistemadistribuido.original;
import java.io.IOException;
import java.io.OutputStream;

public class InvertOutputStream extends OutputStream {

	private OutputStream out;

	public InvertOutputStream(final OutputStream out) {
		this.out = out;
	}

	@Override
    public void write(final int b) throws IOException {
		out.write(b);
	}

	@Override
    public void write(final byte[] bytes) throws IOException {
		write(bytes, 0, bytes.length-1);
	}

	@Override
    public void write(final byte[] bytes, final int ini, final int fim) throws IOException {
		int realFim = fim;
		int realIni = ini;
		if (realFim > bytes.length - 1) {
			realFim = bytes.length - 1;
		}
		if (realIni < 0) {
			realIni = 0;
		}
		for (int i = realFim; i >= realIni; i--) {
			write(bytes[i]);
		}
	}

	@Override
    public void flush() throws IOException {
		out.flush();
	}
}