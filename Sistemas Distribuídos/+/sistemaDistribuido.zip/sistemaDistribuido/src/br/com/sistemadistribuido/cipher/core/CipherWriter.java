package br.com.sistemadistribuido.cipher.core;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;

import br.com.sistemadistribuido.cipher.util.ListaCircular;

/**
 * Classe que "cifra" os caracteres escritos no stream da seguinte forma:
 * Vogais e consoantes devem ser substitudas pelas suas respectivas letras
 * sucessoras no alfabeto, mantendo o mesmo estilo de "capitalizao" (considere
 * o alfabeto como uma lista circular). Todos os outros tipos de caracteres
 * (acentos, sinais de pontuao, s�mbolos, etc) devem ser mantidos inalterados.
 *
 * @author Tiago, Samira e Romulo
 * @since 31/08/2009
 */
public class CipherWriter extends Writer {

    /**
     * OutputStreamWriter que ser� cifrado
     */
    private OutputStreamWriter outputStreamWriter;

    private final ListaCircular listaCircular;

    /**
     * Construtor da classe
     *
     * @param outputStreamWriter O OutputStreamWriter que ser� cifrado
     */
    public CipherWriter(final OutputStreamWriter outputStreamWriter) {
        this.outputStreamWriter = outputStreamWriter;
        this.listaCircular = new ListaCircular();
    }

    /**
     * Fecha o stream
     *
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        outputStreamWriter.close();
    }

    /**
     * Libera o fluxo
     *
     * @throws IOException
     */
    @Override
    public void flush() throws IOException {
        outputStreamWriter.flush();
    }

    /**
     * Escreve um array de caracteres completo
     *
     * @param cbuf
     * @throws IOException
     */
    @Override
    public void write(final char[] cbuf) throws IOException {
        write(cbuf, 0, cbuf.length - 1);
    }

    /**
     * Escreve uma string completa
     *
     * @param str
     * @throws IOException
     */
    @Override
    public void write(final String str) throws IOException {
        write(str, 0, str.length() - 1);
    }

    /**
     * Escreve uma string a partir do �nicio e fim
     * passados como par�metro
     *
     * @param str
     * @param inicio
     * @param fim
     * @throws IOException
     */
    @Override
    public void write(final String str, final int inicio, final int fim) throws IOException {
        write(str.toCharArray(), inicio, fim);
    }

    /**
     * Escreve um array de caracteres de forma "cifrada" (usando as regras
     * definidas no coment�rio da classe) a partir do �nicio e fim
     * passados como par�metros.
     *
     * @param cbuf
     * @param inicio
     * @param fim
     * @throws IOException
     */
    @Override
    public void write(final char[] cbuf, final int inicio, final int fim) throws IOException {
        int pos;
        char caractere;

        //Percorrendo o Array de caracteres
        for (final char c : cbuf) {
            caractere = c;
            //Percorrendo as listasCirculares
            for (final List<Character> lista : listaCircular.listasCirculares) {
                //Verificando se o caractere est� na listaCircular
                if ((pos = lista.indexOf(c)) > -1) {
                    //Tratamento pra evitar IndexOutOfBoundsException
                    if (pos >= lista.size() - 1) {
                        pos = -1;
                    }
                    //Se tiver na lista, pega o pr�ximo
                    caractere = lista.get(pos + 1);
                    break;
                }
            }
            //Escrevendo o caractere
            outputStreamWriter.write(caractere);
        }
    }
}
