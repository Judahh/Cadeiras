package br.com.sistemadistribuido.original;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class StringUDPConnector extends StringConnector {
	private InetAddress server;
	private int port;
	
	public StringUDPConnector(InetAddress address, int port) {
		super(address, port);
		this.server = address;
		this.port = port;
	}

	@Override
	String receive() throws IOException {
		byte[] buffer = new byte[1000];
		DatagramSocket datragramSocket = new DatagramSocket(port);
		DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
		datragramSocket.receive(packet);
		return new String(packet.getData());
	}

	@Override
	void send(String msn) throws IOException {
		DatagramSocket datagramSocket = new DatagramSocket();
		byte[] data = msn.getBytes();
		DatagramPacket packet = new DatagramPacket(data,data.length,server,port);
		datagramSocket.send(packet);
	}

}
