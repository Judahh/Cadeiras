package br.com.sistemadistribuido.api.core.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import br.com.sistemadistribuido.api.core.factory.ServerFactory;
import br.com.sistemadistribuido.api.core.server.AbstractServer;
import br.com.sistemadistribuido.api.util.Util;

public class MainServer {
	
	public static void main(String[] args) throws IOException {
		
		int opcao = capturaOpcaoUsuario();

		if (opcao != 1 && opcao != 2) {
			return;
		}
		
		AbstractServer abstractServer = ServerFactory.createServer(opcao, Util.PORTA);
		abstractServer.aceitaConexao();

	}
	
	private static int capturaOpcaoUsuario() throws IOException {
        exibeMenu();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        return Integer.parseInt(in.readLine());
    }

    private static void exibeMenu() {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Escolha a op��o desejada:\n");
        stringBuilder.append("[1] - Cria Servidor Socket TCP\n");
        stringBuilder.append("[2] - Cria Servidor Socket UDP\n");
        stringBuilder.append("[3] - Sair\n");
        stringBuilder.append("X-------------------------------------------X\n");
        stringBuilder.append("Op��o:");

        System.out.println(stringBuilder);

    }

}
