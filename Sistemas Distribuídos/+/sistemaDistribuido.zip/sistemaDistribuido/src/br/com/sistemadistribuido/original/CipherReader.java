package br.com.sistemadistribuido.original;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;


public class CipherReader extends Reader {
	
	InputStreamReader isr;
	
	public CipherReader(InputStreamReader isr) {
		this.isr = isr;
	}

	@Override
	public void close() throws IOException {
		isr.close();
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		int pos, count = 0;
		char caractere, tempArray[] = new char[len];
		isr.read(tempArray);
		for (char c : tempArray) {
			caractere = c;
			for (List<Character> lista : CipherWriter.listasCirculares) {
				if ((pos = lista.indexOf(c)) > -1) {
					if (pos == 0) {
						pos = lista.size();
					}
					caractere = lista.get(pos - 1);
					break;
				}
			}
			cbuf[count] = caractere;
			count++;
		}
		return 0;
	}
}
