package br.com.sistemadistribuido.original;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
 public class Client {  
   
    public static void main(String[] args) {  
       int port = 5678;  
       InetAddress ia = null;     
       try {     
          ia = InetAddress.getLocalHost();     
       } catch (UnknownHostException e) {     
          e.printStackTrace();     
       }     
   
       //String IP = ia.getHostAddress();  
       String IP = "localhost";  
       String inFile = "C:\\testeServer.txt";  
       String outFile = "testeCliente.txt";  
       try {  
          Socket MyCliente = new Socket(IP,port);  
   
          File file = new File(outFile);  
   
          DataInputStream input = new DataInputStream(new FileInputStream(file));  
          DataOutputStream output = new DataOutputStream(new FileOutputStream(inFile));  
   
          DataInputStream inputMsg = new DataInputStream(MyCliente.getInputStream());  
          DataOutputStream outputMsg = new DataOutputStream(MyCliente.getOutputStream());  
   
          outputMsg.writeUTF(ia.getHostAddress());  
          outputMsg.writeUTF(ia.getHostName());  
   
          int readByte = inputMsg.read();     
          while (readByte !=-1) {     
             output.write((byte)readByte);     
             readByte = inputMsg.read();     
          }    
   
          byte[] cache = new byte[10240];   
          int size = 0;   
          while ((size = input.read(cache)) > -1)    
             outputMsg.write(cache, 0, size);   
   
          inputMsg.close();  
          outputMsg.close();  
          input.close();  
          output.close();  
          MyCliente.close();  
       } catch (Exception e) {  
          System.err.println(e.toString());  
       }  
    }  
 }  