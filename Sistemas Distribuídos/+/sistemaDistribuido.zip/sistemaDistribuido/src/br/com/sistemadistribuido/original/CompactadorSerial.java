package br.com.sistemadistribuido.original;
public class CompactadorSerial {

    /**
     * @param args
     */
    public static void main(String[] args) {
        long endTime, initTime = System.currentTimeMillis();

        for (String nomeArquivo : args) {
            new Compactador(nomeArquivo).run();
        }
        System.out.println("Arquivos compactados com sucesso.");
        endTime = System.currentTimeMillis();
        System.out.println("FINALIZADO.");
        System.out.println("Tempo final decorrido: "
                + Compactador.exibeEmHoras(endTime - initTime) + "("
                + (endTime - initTime) + ")");
    }
}
