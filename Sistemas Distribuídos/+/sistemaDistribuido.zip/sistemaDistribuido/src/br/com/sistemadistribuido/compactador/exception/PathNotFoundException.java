package br.com.sistemadistribuido.compactador.exception;

/**
 * Valida��o para o FileUtil
 */
public class PathNotFoundException extends Exception {

	private static final long serialVersionUID = -7420092430948130819L;

	public PathNotFoundException(String message) {
		super(message);
	}
}
