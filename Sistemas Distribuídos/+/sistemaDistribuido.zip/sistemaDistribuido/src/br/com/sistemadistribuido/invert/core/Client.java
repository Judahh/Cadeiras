package br.com.sistemadistribuido.invert.core;

import java.io.IOException;

import javax.swing.JOptionPane;

/**
 * Classe Cliente que vai testar as classes InvertOutputStream e InvertInputStream.
 *
 * @author Tiago, Samira e Romulo
 * @since 25/08/2009
 */
public class Client {

    /**
     * M�todo principal que inicia a execu��o do sistema e exibe o menu.
     *
     * @param args
     */
    public static void main(final String[] args) {

        try {

            final StringBuilder menu = new StringBuilder();
            menu.append("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\n");
            menu.append("------------- Menu do Sistema ----------\n");
            menu.append("[1] - Inverter usando o InvertOutputStream\n");
            menu.append("[2] - Inverter usando o InvertInputStream\n");
            menu.append("[3] - Inverter usando o InvertOutputStream e des-inverter usando o InvertInputStream\n");
            menu.append("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

            final String opcao = JOptionPane.showInputDialog(menu.toString());

            if (opcao.equals("1")) {
                testInvertOutputStream();
            } else if (opcao.equals("2")) {
                testInvertInputStream();
            } else if (opcao.equals("3")) {
                testInvertOutputStreamAndInvertInputStream();
            }

        } catch (final IOException e) {
            System.out.println("Ocorreu algum problema na entrada dos dados.\n" +
            		"Tente novamente mais tarde.");
        }
    }

    /**
     * M�todo de teste para a classe InvertOutputStream. Esse m�todo l�
     * do teclado um valor, depois cria um InvertOutputStream (OutputStream invertido)
     * e manda imprimir na tela.
     *
     * @throws IOException
     */
    private static void testInvertOutputStream() throws IOException {

        System.out.println("\nX--------------------------- Testando o InvertOutputStream ----------------------------X\n ");

        final byte[] bytes = new byte[5];

        System.out.print("Digite o Texto a ser invertido pelo InvertOutputStream: [5 caracteres]");

        //Lendo o texto do teclado
        System.in.read(bytes);

        //Criando o OutputStream invertido
        final InvertOutputStream invertOutputStream = new InvertOutputStream(System.out);

        System.out.print("Texto invertido: ");

        //Escrevendo o texto invertido
        invertOutputStream.write(bytes);

        invertOutputStream.flush();
        System.out.flush();

    }

    /**
     * M�todo de teste para a classe InvertInputStream. Esse m�todo cria
     * um InvertInputStream (InputStream invertido) e l� do teclado um
     * valor ja invertido, e manda imprimir na tela.
     *
     * @throws IOException
     */
    private static void testInvertInputStream() throws IOException {

        System.out.println("\nX--------------------------- Testando o InvertInputStream ----------------------------X\n ");

        //Criando o InputStream invertido
        final InvertInputStream invertOutputStream = new InvertInputStream(System.in);

        final byte[] bytes = new byte[5];

        System.out.print("Digite o texto a ser invertido pelo InvertInputStream: [5 caracteres]");

        //Lendo o texto de forma invertida
        invertOutputStream.read(bytes);

        //Escrevendo o texto
        System.out.println("Texto invertido: " + new String(bytes));

    }

    /**
     * M�todo de teste para a classe InvertOutputStream e InvertInputStream. Esse m�todo cria
     * um InvertInputStream (InputStream invertido) e l� do teclado um
     * valor ja invertido, emm seguida cria um  um InvertOutputStream (OutputStream invertido)
     * e manda imprimir na tela manda imprimir na tela. O Valor impresso ser� igual ao digitado
     * pelo usu�rio.
     *
     * @throws IOException
     */
    private static void testInvertOutputStreamAndInvertInputStream() throws IOException {

        System.out.println("\nX--------------------------- Testando o InvertOutputStream e InvertInputStream ----------------------------X\n ");

        //Criando o InputStream invertido
        final InvertInputStream iis = new InvertInputStream(System.in);

        final byte[] bytes = new byte[5];

        System.out.print("Digite o texto a ser invertido pelo InvertInputStream \n" +
        		"e des-invertido pelo : InvertOutputStream[5 caracteres]");

        //Lendo o texto de forma invertida
        iis.read(bytes);

        //Criando o OutputStream invertido
        final InvertOutputStream ios = new InvertOutputStream(System.out);

        System.out.print("Texto normal: ");

        //Escrevendo de forma invertida, ou seja, o texto deve sair normal.
        ios.write(bytes);

        ios.flush();

    }

}
