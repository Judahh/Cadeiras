package br.com.sistemadistribuido.original;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public final class HttpSocket {

	public static void main(String[] args) {
		try{
			Socket socket = new Socket("www.datavideosom.com.br",80);
			
			// Criando um canal para receber dados
			DataInputStream input = new DataInputStream(socket.getInputStream());
			
			// Criando um canal para enviar os dados
			DataOutputStream output = new DataOutputStream(socket.getOutputStream());
			output.writeUTF("GET http://www.datavideosom.com.br/fortaleza/empresa.html");
			
			String response = input.readUTF();
			System.out.println(response);
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	/**
	 * SocketChannel socketChanel = null;
		try{
			InetSocketAddress socketAddress = new InetSocketAddress("www.sumersoft.com.br",80);
			socketChanel = SocketChannel.open(socketAddress);
			socketChanel.write(charset.encode("GET /index.html\r\n\r\n"));
			ByteBuffer buffer = ByteBuffer.allocate(2048);
			while ((socketChanel.read(buffer)) != - 1){
				buffer.flip();
				System.out.println(charset.decode(buffer));
				buffer.clear();
			}
			
		}catch(Exception e){
			e.printStackTrace();
			
		}finally{
			if (socketChanel != null){
				try{
					socketChanel.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	 */

}
