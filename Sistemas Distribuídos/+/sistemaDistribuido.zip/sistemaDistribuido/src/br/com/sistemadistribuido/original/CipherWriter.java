package br.com.sistemadistribuido.original;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * Vogais e consoantes devem ser substitudas pelas suas respectivas letras
 * sucessoras no alfabeto, mantendo o mesmo estilo de "capitalizao" (considere
 * o alfabeto como uma lista circular). Todos os outros tipos de caracteres
 * (acentos, sinais de pontuao, smbolos, etc) devem ser mantidos inalterados.
 *
 * @author Pedro Ciarlini.....
 * @since 2007-03-16
 */
public class CipherWriter extends Writer {

	OutputStreamWriter osw;

	public static final List<List> listasCirculares = new ArrayList<List>();

	{
		char[] temp;
		List<Character> listaCircular;

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'a', 'e', 'i', 'o', 'u' };
		for (final char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l',
				'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z' };
		for (final char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'A', 'E', 'I', 'O', 'U' };
		for (final char vogal : temp) {
			listaCircular.add(vogal);
		}
		listasCirculares.add(listaCircular);

		listaCircular = new ArrayList<Character>();
		temp = new char[] { 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L',
				'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };
		for (final char consoante : temp) {
			listaCircular.add(consoante);
		}
		listasCirculares.add(listaCircular);
	}

	public CipherWriter(final OutputStreamWriter osw) {
		this.osw = osw;
	}

	@Override
	public void close() throws IOException {
		osw.close();
	}

	@Override
	public void flush() throws IOException {
		osw.flush();
	}

	@Override
	public void write(final char[] cbuf, final int off, final int len) throws IOException {
		int pos;
		char caractere;
		for (final char c : cbuf) {
			caractere = c;
			for (final List<Character> lista : CipherWriter.listasCirculares) {
				if ((pos = lista.indexOf(c)) > -1) {
					if (pos >= lista.size()) {
						pos = -1;
					}
					caractere = lista.get(pos + 1);
					break;
				}
			}
			osw.write(caractere);
		}
	}
}