package br.com.sistemadistribuido.api.core.client;

import static br.com.sistemadistribuido.api.util.UDPUtil.getDadosValidos;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;

import br.com.sistemadistribuido.api.util.Util;

public class UDPConnectorImpl extends AbstractConnector {

	private InetAddress server;
	private int porta;
	private DatagramSocket datagramSocket;

	public UDPConnectorImpl(InetAddress endereco, int porta) {
		super(endereco, porta);
		this.server = endereco;
		this.porta = porta;
	}

	@Override
	public String recebeMsg() throws IOException {
        byte[] buffer = new byte[1000];
        DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
        datagramSocket.receive(packet);
        return getDadosValidos(packet);
	}

	@Override
	public void enviaMsg(String mensagem) throws IOException {
		datagramSocket = new DatagramSocket();
		byte[] data = mensagem.getBytes();
		DatagramPacket packet = new DatagramPacket(data, data.length, server, porta);
		datagramSocket.send(packet);
	}

	@Override
	public void enviaFile(File arquivo) throws IOException {
		
		Date dataAtualizacao = new Date();
		
		//Atualizando as informa��es sobre o cache
		Util.atualizaCache(arquivo.getName(), dataAtualizacao);
		
		//Avisando que vai enviar um arquivo
		datagramSocket = new DatagramSocket();
		byte[] data = ("PUTFILE " + arquivo.getName() +  " " 
				+ dataAtualizacao.getTime()).getBytes();
		
		DatagramPacket packet = new DatagramPacket(data, data.length, server, porta);
		datagramSocket.send(packet);
		
		byte[] dataFile = Util.getBytesFromFile(arquivo);
		DatagramPacket packetFile = new DatagramPacket(dataFile, dataFile.length, server, porta);
		
		datagramSocket.send(packetFile);
		
	}

	@Override
	public File recebeFile() throws IOException {

		String mensagem =  recebeMsg();
		
		String [] mensagens = mensagem.split(" ");
		
		String nomeArquivo = mensagens[1];
		
		Date dataAtualizacao = new Date(Long.parseLong(mensagens[2]));
		
		Util.atualizaCache(nomeArquivo, dataAtualizacao);
		
		System.out.println("Recebendo do Servidor o arquivo: " + nomeArquivo);
		
		String inFile = Util.pathCliente + nomeArquivo;

		File file = new File(inFile);
		
		FileOutputStream fileOutputStream = new FileOutputStream(file);

		byte[] buffer = new byte[1000];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		
		datagramSocket.receive(packet);
		
		fileOutputStream.write(packet.getData());
		
		fileOutputStream.close();
		fileOutputStream.flush();
		
		return null;
	}

}
