

public class Main {

	public static void main(String[] args) {

		String str = "teste";
		byte[] b = new byte[str.length()];
		str.getBytes(0, str.length(), b, 0);
		
		new InvertOutputStream().write(b);
		new InvertOutputStream().write(b, 0, 5);
		
	}

}
