import java.io.IOException;
import java.io.OutputStream;


public class InvertOutputStream extends OutputStream{

	OutputStream out;
	
	public InvertOutputStream(OutputStream out){
		this.out = out;
	}

	
	@Override
	public void write(int b) throws IOException {
		this.out.write(b);
	}

	public void write(byte[] data) {
		byte[] temp = inverterByte(data);
		print(temp);
	}
	public void write(byte[] data, int offset, int length) {
		if (length > data.length || offset > length) {
			System.out.println("offset ou length errado");
		} else {
			byte [] temp = new byte[length];
			int count = 0;
			for (int i = offset; i <length; i++) {
				temp[count] = data[i];
				count++;
			}
			temp = inverterByte(temp);
			print(temp);
		}
		
	}
	
	private byte[] inverterByte(byte[] data){
		byte [] temp = new byte[data.length];
		int count =0;
		for (int d = data.length-1;  d>=0; d--) {
			temp[count]=data[d];
			count++;
		}
		return temp;
	}
	
	private void print (byte [] temp){
		for (int i = 0; i < temp.length; i++) {
			try {
				write(temp[i]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		try {
			this.out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}	
