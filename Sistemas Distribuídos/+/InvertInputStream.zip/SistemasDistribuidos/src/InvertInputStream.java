import java.io.IOException;
import java.io.InputStream;


public class InvertInputStream  extends InputStream{
	
	private InputStream inputStream;
	public InvertInputStream(InputStream inputStream){
		this.inputStream = inputStream;
	}
	
	@Override
	public int read() throws IOException {
		return inputStream.read();
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int i = 0;
		int count = 0; 
		for (int j = 0; j < len; j++) {
			char c = (char) read();;
			b[count] = (byte)c;
			count++;
		}
		
		System.out.println(i);
		return len;
	}

	private byte[] inverterByte(byte[] data){
		byte [] temp = new byte[data.length];
		int count =0;
		for (int d = data.length-1;  d>=0; d--) {
			temp[count]=data[d];
			count++;
		}
		return temp;
	}
}
