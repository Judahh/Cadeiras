import java.io.IOException;





public class Main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		/*String str = "teste";
		byte[] b = new byte[str.length()];
		str.getBytes(0, str.length(), b, 0);
		
		new InvertOutputStream(System.out).write(b);
		System.out.println("");
		new InvertOutputStream(System.out).write(b, 0, 5);*/
		
		
		try {
			InvertInputStream invertInputStream = new InvertInputStream(System.in);
			byte[] data = new byte[100];
			int result = invertInputStream.read(data, 0,4);
			
			new InvertOutputStream(System.out).write(data);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
