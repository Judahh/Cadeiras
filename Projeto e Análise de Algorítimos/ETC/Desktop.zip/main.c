#include <stdio.h>
#include <stdlib.h>

int merge(int q, int p, int r,int A[r+1]){
    int n1=q-p+1;
    int n2=r-q;
    int L[n1+2];
    int R[n2+2];
    int i=0;
    int j=0;
    int k=0;
    printf("L=");
    for(i=0;i<=n1;i++){
          L[i]=A[p+i-1];
          printf("%d",L[i]);
    }
    printf("\n");
    printf("R=");
    for(i=0;i<=n1;i++){
          R[i]=A[q+i];
          printf("%d",R[i]);
    }
    printf("\n");
    
    int inf=999999;
    
    L[n1+1]=inf;
    R[n2+1]=inf;
    i=0;
    j=0;
    for(k=p;k<=r;k++){
          if(L[i]<=R[j]){
                A[k]=L[i];
                i++;                
          }else{
                A[k]=R[j];
                j++;      
          }
    }
    for(i=0;i<=r;i++){
          printf("%d",A[i]);
    }
    printf("\n");
    return 0;
}

int main(int argc, char *argv[]){
    int vec[8]={2,4,5,7,1,2,3,6};
    merge(3,0,7,vec);
    system("PAUSE");	
    return 0;
}
